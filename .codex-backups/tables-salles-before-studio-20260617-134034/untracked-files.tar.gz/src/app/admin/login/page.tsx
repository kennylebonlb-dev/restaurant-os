"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { ArrowRight, KeyRound, Loader2, LockKeyhole, Mail, ShieldCheck } from "lucide-react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import { FormEvent, Suspense, useEffect, useState } from "react";
import { apiFetch } from "@/hooks/use-api";
import type { PlatformBrand } from "@/server/platform-settings";

type BrandResponse = {
  brand: PlatformBrand;
};

type RestaurantAccessResponse = {
  restaurants: Array<{
    id: string;
    name: string;
    slug: string;
  }>;
};

function currentHost() {
  if (typeof window === "undefined") {
    return "";
  }

  return window.location.hostname.toLowerCase();
}

function isRootToqueTopHost(hostname: string) {
  return hostname === "toquetop.com" || hostname === "www.toquetop.com";
}

function AdminLoginContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const resetToken = searchParams.get("resetToken");
  const initialEmail = searchParams.get("email") ?? "";
  const callbackUrl = searchParams.get("callbackUrl") ?? "/admin";
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(true);
  const [forgotEmail, setForgotEmail] = useState(initialEmail);
  const [resetPassword, setResetPassword] = useState("");
  const [mode, setMode] = useState<"login" | "forgot" | "reset">(resetToken ? "reset" : "login");
  const [message, setMessage] = useState<string>();
  const [error, setError] = useState<string>();
  const [hostnameLabel, setHostnameLabel] = useState("");

  const brandQuery = useQuery({
    queryKey: ["platform-brand"],
    queryFn: () => apiFetch<BrandResponse>("/api/platform-brand"),
    staleTime: 60_000
  });

  const brand = brandQuery.data?.brand;
  const visualUrl = brand?.adminLoginVisualUrl ?? brand?.loginVisualUrl;
  const logoUrl = brand?.logoUrl ?? brand?.marketingLogoUrl ?? "/toquetop-logo.svg";
  const logoAlt = brand?.logoAlt ?? "ToqueTop";

  useEffect(() => {
    setHostnameLabel(currentHost().replace(".toquetop.com", ""));
  }, []);

  const forgotPasswordMutation = useMutation({
    mutationFn: () =>
      apiFetch<{ message: string }>("/api/auth/forgot-password", {
        method: "POST",
        body: JSON.stringify({
          email: forgotEmail,
          redirectPath: "/admin/login"
        })
      }),
    onSuccess: (data) => {
      setError(undefined);
      setMessage(data.message);
    },
    onError: (forgotError) => {
      setError(forgotError.message);
    }
  });

  const resetPasswordMutation = useMutation({
    mutationFn: () =>
      apiFetch<{ message: string }>("/api/auth/reset-password", {
        method: "POST",
        body: JSON.stringify({
          email: forgotEmail || email,
          password: resetPassword,
          token: resetToken
        })
      }),
    onSuccess: (data) => {
      setMessage(data.message);
      setError(undefined);
      setEmail(forgotEmail || email);
      setPassword(resetPassword);
      setResetPassword("");
      setMode("login");
      router.replace("/admin/login");
    },
    onError: (resetError) => {
      setError(resetError.message);
    }
  });

  async function redirectAfterLogin() {
    const access = await apiFetch<RestaurantAccessResponse>("/api/restaurants/current");
    const hostname = currentHost();

    if (access.restaurants.length === 0) {
      setError("Ce compte n’est associé à aucun restaurant.");
      return;
    }

    if (isRootToqueTopHost(hostname) && access.restaurants.length === 1) {
      router.push("/admin");
      router.refresh();
      return;
    }

    router.push(callbackUrl.startsWith("/admin") ? callbackUrl : "/admin");
    router.refresh();
  }

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(undefined);
    setMessage(undefined);

    const result = await signIn("credentials", {
      email,
      password,
      rememberMe: rememberMe ? "true" : "false",
      redirect: false
    });

    if (result?.error) {
      setError("L’e-mail ou le mot de passe est incorrect.");
      return;
    }

    try {
      await redirectAfterLogin();
    } catch (loginError) {
      setError(loginError instanceof Error ? loginError.message : "Connexion impossible pour le moment.");
    }
  }

  function handleForgotPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    forgotPasswordMutation.mutate();
  }

  function handleResetPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    resetPasswordMutation.mutate();
  }

  return (
    <main className="grid min-h-screen bg-linen p-4 text-ink lg:grid-cols-[minmax(420px,0.92fr)_minmax(430px,560px)] lg:gap-6 lg:p-6">
      <section className="relative hidden min-h-[calc(100vh-3rem)] overflow-hidden rounded-lg bg-ink shadow-soft lg:block">
        {visualUrl ? (
          <img
            alt="Salle de restaurant"
            className="absolute inset-0 h-full w-full object-cover"
            src={visualUrl}
          />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-b from-ink/50 via-ink/20 to-ink/78" />
        <div className="relative flex h-full flex-col justify-between p-10 text-white">
          <img alt={logoAlt} className="h-14 w-auto max-w-72 object-contain brightness-0 invert" src={logoUrl} />
          <div className="max-w-xl">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-3 py-1 text-xs font-black uppercase tracking-[0.16em]">
              <ShieldCheck className="h-4 w-4" />
              Accès restaurant
            </p>
            <h1 className="text-5xl font-black leading-[0.96] tracking-normal">
              Pilotez votre salle en direct.
            </h1>
            <p className="mt-5 max-w-md text-sm font-semibold leading-6 text-white/78">
              Connectez-vous au Dashboard Live pour gérer les réservations, les tables, les services et vos clients en temps réel.
            </p>
          </div>
        </div>
      </section>

      <section className="flex min-h-[calc(100vh-2rem)] items-center justify-center py-8 lg:min-h-[calc(100vh-3rem)]">
        <div className="w-full max-w-xl">
          <div className="mb-8 lg:hidden">
            <img alt={logoAlt} className="h-12 w-auto object-contain" src={logoUrl} />
          </div>

          <div className="rounded-lg border border-ink/10 bg-white p-6 shadow-soft sm:p-8">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.16em] text-moss">Dashboard Live</p>
              <h2 className="mt-2 text-3xl font-black text-ink">
                {mode === "reset" ? "Modifier le mot de passe" : mode === "forgot" ? "Mot de passe oublié" : "Connexion restaurant"}
              </h2>
              <p className="mt-2 text-sm font-semibold leading-6 text-ink/60">
                {hostnameLabel && hostnameLabel !== "localhost" && hostnameLabel !== "127.0.0.1"
                  ? `Accès sécurisé pour ${hostnameLabel}.`
                  : "Accès sécurisé au Dashboard Live de votre restaurant."}
              </p>
            </div>

            {message ? (
              <p className="mt-5 rounded-md border border-moss/20 bg-moss/10 p-3 text-sm font-bold text-moss">{message}</p>
            ) : null}
            {error ? (
              <p className="mt-5 rounded-md border border-red-200 bg-red-50 p-3 text-sm font-bold text-red-700">{error}</p>
            ) : null}

            {mode === "login" ? (
              <form className="mt-6 grid gap-4" onSubmit={handleLogin}>
                <label className="text-sm font-bold text-ink">
                  E-mail
                  <div className="relative mt-1">
                    <Mail className="field-icon" />
                    <input
                      autoComplete="email"
                      className="control with-leading-icon w-full"
                      inputMode="email"
                      required
                      type="email"
                      value={email}
                      onChange={(event) => setEmail(event.target.value)}
                    />
                  </div>
                </label>
                <label className="text-sm font-bold text-ink">
                  Mot de passe
                  <div className="relative mt-1">
                    <LockKeyhole className="field-icon" />
                    <input
                      autoComplete="current-password"
                      className="control with-leading-icon w-full"
                      required
                      type="password"
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                    />
                  </div>
                </label>
                <div className="flex flex-wrap items-center justify-between gap-3 text-sm font-semibold text-ink/65">
                  <label className="inline-flex items-center gap-2">
                    <input
                      checked={rememberMe}
                      className="h-4 w-4 accent-moss"
                      type="checkbox"
                      onChange={(event) => setRememberMe(event.target.checked)}
                    />
                    Se souvenir de moi
                  </label>
                  <button className="font-black text-moss hover:underline" type="button" onClick={() => setMode("forgot")}>
                    Mot de passe oublié
                  </button>
                </div>
                <button className="primary-button mt-2 w-full" type="submit">
                  Accéder au Dashboard
                  <ArrowRight className="h-4 w-4" />
                </button>
              </form>
            ) : null}

            {mode === "forgot" ? (
              <form className="mt-6 grid gap-4" onSubmit={handleForgotPassword}>
                <label className="text-sm font-bold text-ink">
                  E-mail du compte restaurant
                  <div className="relative mt-1">
                    <Mail className="field-icon" />
                    <input
                      autoComplete="email"
                      className="control with-leading-icon w-full"
                      inputMode="email"
                      required
                      type="email"
                      value={forgotEmail}
                      onChange={(event) => setForgotEmail(event.target.value)}
                    />
                  </div>
                </label>
                <button className="primary-button w-full" disabled={forgotPasswordMutation.isPending} type="submit">
                  {forgotPasswordMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />}
                  Recevoir le lien de réinitialisation
                </button>
                <button className="secondary-button w-full" type="button" onClick={() => setMode("login")}>
                  Retour à la connexion
                </button>
              </form>
            ) : null}

            {mode === "reset" ? (
              <form className="mt-6 grid gap-4" onSubmit={handleResetPassword}>
                <label className="text-sm font-bold text-ink">
                  E-mail
                  <div className="relative mt-1">
                    <Mail className="field-icon" />
                    <input
                      autoComplete="email"
                      className="control with-leading-icon w-full"
                      inputMode="email"
                      required
                      type="email"
                      value={forgotEmail}
                      onChange={(event) => setForgotEmail(event.target.value)}
                    />
                  </div>
                </label>
                <label className="text-sm font-bold text-ink">
                  Nouveau mot de passe
                  <div className="relative mt-1">
                    <LockKeyhole className="field-icon" />
                    <input
                      autoComplete="new-password"
                      className="control with-leading-icon w-full"
                      minLength={8}
                      required
                      type="password"
                      value={resetPassword}
                      onChange={(event) => setResetPassword(event.target.value)}
                    />
                  </div>
                </label>
                <button className="primary-button w-full" disabled={resetPasswordMutation.isPending} type="submit">
                  {resetPasswordMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />}
                  Modifier le mot de passe
                </button>
              </form>
            ) : null}
          </div>
        </div>
      </section>
    </main>
  );
}

export default function AdminLoginPage() {
  return (
    <Suspense
      fallback={
        <main className="grid min-h-screen place-items-center bg-linen">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-moss/20 border-t-moss" />
        </main>
      }
    >
      <AdminLoginContent />
    </Suspense>
  );
}
