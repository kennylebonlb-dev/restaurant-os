"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import clsx from "clsx";
import {
  Bell,
  Bot,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock3,
  CreditCard,
  Gift,
  Image,
  Info,
  LayoutDashboard,
  LifeBuoy,
  List,
  LogOut,
  Mail,
  MessageSquare,
  PanelLeftClose,
  PanelLeftOpen,
  Phone,
  Plug,
  Plus,
  Radio,
  Settings,
  Shield,
  Sparkles,
  Table2,
  Timer,
  UserRound,
  Users
} from "lucide-react";
import { signOut } from "next-auth/react";
import { FormEvent, ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { DashboardModal } from "@/components/dashboard/dashboard-modal";
import { FloorPlan } from "@/components/floor-plan/floor-plan";
import { apiFetch } from "@/hooks/use-api";
import { useRestaurantSocket } from "@/hooks/use-socket-events";
import type { FloorTable, OpeningHours, TableBlockReason, TableFeature, VacationClosure } from "@/lib/domain";
import {
  applyFloorPlanSettings,
  floorPlan2dImageUrlFromSettings,
  floorPlanModelUrlFromSettings
} from "@/lib/floor-plan-settings";
import { addDaysToDateString, addMinutes, getDayKey, getZonedDateTimeParts, minutesToTime, parseTimeToMinutes } from "@/lib/time";
import { useFloorPlanStore } from "@/stores/floor-plan-store";

type Restaurant = {
  id: string;
  name: string;
  slug: string;
  address: string | null;
  phone: string | null;
  timezone: string;
  openingHours: OpeningHours;
  settings: Record<string, unknown>;
  layoutLocked: boolean;
  tables: FloorTable[];
};

type Reservation = {
  id: string;
  referenceCode: string | null;
  date: string;
  startTime: string;
  endTime: string;
  numberOfGuests: number;
  status: "PENDING" | "CONFIRMED" | "CANCELLED";
  notes: string | null;
  guestFirstName: string | null;
  guestLastName: string | null;
  guestEmail: string | null;
  guestPhone: string | null;
  highChair: boolean;
  birthday: boolean;
  romanticDinner: boolean;
  arrivedAt?: string | null;
  noShow?: boolean;
  table: { id: string; label: string } | null;
  client?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string | null;
    phone: string | null;
    vip: boolean;
    noShowRisk: number;
  } | null;
};

type Client = {
  id: string;
  firstName: string;
  lastName: string;
  email: string | null;
  phone: string | null;
  birthday: string | null;
  allergies: string | null;
  preferences: string[];
  internalNotes: string | null;
  vip: boolean;
  noShowRisk: number;
  reservations: Array<{
    id: string;
    referenceCode: string | null;
    date: string;
    startTime: string;
    numberOfGuests: number;
    status: string;
    noShow: boolean;
  }>;
};

type WaitlistEntry = {
  id: string;
  date: string;
  requestedTime: string | null;
  numberOfGuests: number;
  status: "WAITING" | "SEATED" | "CANCELLED" | "EXPIRED";
  firstName: string;
  lastName: string;
  email: string | null;
  phone: string | null;
  notes: string | null;
};

type ChefInsight = {
  id: string;
  level: "info" | "warning" | "critical";
  title: string;
  message: string;
  actionLabel?: string;
};

type AuditEvent = {
  id: string;
  action: string;
  entityType: string;
  entityId: string | null;
  createdAt: string;
  actor: { name: string | null; email: string } | null;
};

type AdminSection =
  | "dashboard"
  | "guide"
  | "general"
  | "reservations"
  | "crm"
  | "services"
  | "gallery"
  | "giftCards"
  | "team"
  | "notifications"
  | "integrations"
  | "subscription"
  | "stats";

type ReservationView = "list" | "calendar" | "timeline";
type ServiceFilter = "lunch" | "dinner";
type ModalState = "createReservation" | "editReservation" | "blockTable" | "waitlist" | "client" | null;

const menuItems: Array<{ id: AdminSection; label: string; icon: ReactNode }> = [
  { id: "dashboard", label: "Tableau de bord", icon: <LayoutDashboard className="h-4 w-4" /> },
  { id: "guide", label: "Guide de configuration", icon: <Check className="h-4 w-4" /> },
  { id: "general", label: "Général", icon: <Settings className="h-4 w-4" /> },
  { id: "reservations", label: "Réservations", icon: <CalendarDays className="h-4 w-4" /> },
  { id: "crm", label: "CRM", icon: <Users className="h-4 w-4" /> },
  { id: "services", label: "Services", icon: <Timer className="h-4 w-4" /> },
  { id: "gallery", label: "Galerie", icon: <Image className="h-4 w-4" /> },
  { id: "giftCards", label: "Cartes cadeaux", icon: <Gift className="h-4 w-4" /> },
  { id: "team", label: "Équipes", icon: <Shield className="h-4 w-4" /> },
  { id: "notifications", label: "Notifications", icon: <Bell className="h-4 w-4" /> },
  { id: "integrations", label: "Intégrations", icon: <Plug className="h-4 w-4" /> },
  { id: "subscription", label: "Abonnement", icon: <CreditCard className="h-4 w-4" /> },
  { id: "stats", label: "Statistiques", icon: <LayoutDashboard className="h-4 w-4" /> }
];

const generalSubMenu = [
  "Restaurant",
  "Heures d’ouverture",
  "Congés",
  "Tables et salles",
  "Paramètres de réservation",
  "Tags",
  "Types de réservation",
  "Connexions",
  "Avancé"
] as const;

type GeneralPage = (typeof generalSubMenu)[number];

const setupChecklist = [
  "À propos de l’établissement",
  "Horaires",
  "Tables",
  "Reserve with Google",
  "Facebook/Instagram",
  "Types de réservation",
  "SMS"
];

const timeOptions = Array.from({ length: 24 * 4 }, (_, index) => minutesToTime(index * 15));
const dayKeys = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"] as const;
const dayLabels: Record<(typeof dayKeys)[number], string> = {
  monday: "Lundi",
  tuesday: "Mardi",
  wednesday: "Mercredi",
  thursday: "Jeudi",
  friday: "Vendredi",
  saturday: "Samedi",
  sunday: "Dimanche"
};

function today() {
  return new Date().toISOString().slice(0, 10);
}

function operationalMinDate(timeZone?: string | null) {
  const now = getZonedDateTimeParts(timeZone || "Europe/Paris");

  return now.minutes < 3 * 60 ? addDaysToDateString(now.date, -1) : now.date;
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("fr-FR", {
    weekday: "short",
    day: "2-digit",
    month: "short"
  }).format(new Date(`${value}T12:00:00.000Z`));
}

function formatLongDate(value: string) {
  return new Intl.DateTimeFormat("fr-FR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(new Date(`${value}T12:00:00.000Z`));
}

function formatPeriodDate(value: string) {
  const date = new Date(`${value}T12:00:00.000Z`);
  const day = new Intl.DateTimeFormat("fr-FR", { day: "2-digit" }).format(date);
  const month = new Intl.DateTimeFormat("fr-FR", { month: "long" }).format(date);
  const year = new Intl.DateTimeFormat("fr-FR", { year: "numeric" }).format(date);

  return `${day} - ${month} - ${year}`;
}

function normalizeServiceWindows(dayHours: OpeningHours[string] | undefined) {
  if (!dayHours || dayHours.closed) {
    return [];
  }

  const windows: Array<{ service: ServiceFilter; open: string; close: string; openMinutes: number; closeMinutes: number }> = [];
  const addWindow = (service: ServiceFilter, open?: string, close?: string) => {
    if (!open || !close) {
      return;
    }

    try {
      const openMinutes = parseTimeToMinutes(open);
      const closeMinutes = parseTimeToMinutes(close);

      if (closeMinutes > openMinutes) {
        windows.push({ service, open, close, openMinutes, closeMinutes });
      }
    } catch {
      // Invalid draft opening hours are ignored until a valid configuration is saved.
    }
  };

  addWindow("lunch", dayHours.morningOpen, dayHours.morningClose);

  if (dayHours.lunchServiceEnabled !== false) {
    addWindow("lunch", dayHours.open, dayHours.close);
  }

  if (dayHours.secondServiceEnabled) {
    addWindow("dinner", dayHours.secondOpen, dayHours.secondClose);
  }

  if (dayHours.thirdServiceEnabled) {
    addWindow("dinner", dayHours.thirdOpen, dayHours.thirdClose);
  }

  return windows.sort((first, second) => first.openMinutes - second.openMinutes);
}

function reservationMatchesService(reservation: Reservation, service: ServiceFilter, openingHours: OpeningHours, selectedDate: string) {
  const serviceWindows = normalizeServiceWindows(openingHours[getDayKey(selectedDate)]);
  const startMinutes = parseTimeToMinutes(reservation.startTime);

  return serviceWindows.some(
    (serviceWindow) =>
      serviceWindow.service === service &&
      startMinutes >= serviceWindow.openMinutes &&
      startMinutes < serviceWindow.closeMinutes
  );
}

function getRestaurantOpeningStatus(openingHours: OpeningHours, timeZone: string) {
  const now = getZonedDateTimeParts(timeZone || "Europe/Paris");
  const serviceWindows = normalizeServiceWindows(openingHours[getDayKey(now.date)]);
  const activeWindow = serviceWindows.find(
    (serviceWindow) => now.minutes >= serviceWindow.openMinutes && now.minutes < serviceWindow.closeMinutes
  );

  if (activeWindow) {
    return { tone: "open" as const, label: "Ouvert" };
  }

  const nextWindow = serviceWindows.find((serviceWindow) => serviceWindow.openMinutes > now.minutes);

  if (nextWindow && nextWindow.openMinutes - now.minutes <= 30) {
    return { tone: "soon" as const, label: "Ouvre bientôt" };
  }

  return { tone: "closed" as const, label: "Fermé" };
}

function capacityCounts(tables: FloorTable[]) {
  return {
    two: tables.filter((table) => table.capacity <= 2).length,
    four: tables.filter((table) => table.capacity > 2 && table.capacity <= 4).length,
    sixPlus: tables.filter((table) => table.capacity >= 6).length
  };
}

function openingStatusClass(tone: "open" | "soon" | "closed") {
  return {
    open: "bg-moss/10 text-moss border-moss/20",
    soon: "bg-amber-50 text-amber-700 border-amber-200",
    closed: "bg-red-50 text-red-700 border-red-200"
  }[tone];
}

function reservationGuestName(reservation: Reservation) {
  return [reservation.guestFirstName, reservation.guestLastName].filter(Boolean).join(" ") || "Client";
}

function statusLabel(status: Reservation["status"]) {
  return {
    PENDING: "En attente",
    CONFIRMED: "Confirmée",
    CANCELLED: "Annulée"
  }[status];
}

function statusClass(status: Reservation["status"]) {
  return {
    PENDING: "bg-amber-50 text-amber-700 border-amber-200",
    CONFIRMED: "bg-moss/10 text-moss border-moss/20",
    CANCELLED: "bg-red-50 text-red-700 border-red-200"
  }[status];
}

function insightClass(level: ChefInsight["level"]) {
  return {
    info: "border-sky-200 bg-sky-50 text-sky-900",
    warning: "border-amber-200 bg-amber-50 text-amber-900",
    critical: "border-red-200 bg-red-50 text-red-900"
  }[level];
}

function tablePreferenceFromForm(formData: FormData): TableFeature[] {
  return ["QUIET", "ACCESSIBLE", "KIDS", "WINDOW"].filter((feature) => formData.get(feature)) as TableFeature[];
}

export function DashboardLive() {
  const queryClient = useQueryClient();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [section, setSection] = useState<AdminSection>("dashboard");
  const [generalPage, setGeneralPage] = useState<GeneralPage>("Restaurant");
  const [selectedDate, setSelectedDate] = useState(today());
  const [selectedService, setSelectedService] = useState<ServiceFilter>("lunch");
  const [reservationView, setReservationView] = useState<ReservationView>("list");
  const [floorViewMode, setFloorViewMode] = useState<"2d" | "3d">("2d");
  const [floorZoom, setFloorZoom] = useState(1);
  const [modal, setModal] = useState<ModalState>(null);
  const [selectedReservationId, setSelectedReservationId] = useState<string | null>(null);
  const [clientSearch, setClientSearch] = useState("");
  const [chefPrompt, setChefPrompt] = useState("");
  const [chefMessages, setChefMessages] = useState<Array<{ role: "user" | "assistant"; content: string }>>([
    {
      role: "assistant",
      content: "Bonjour, je suis ToqueChef. Posez-moi une question sur le service, les réservations, les tables libres ou la liste d’attente."
    }
  ]);
  const { selectedTableId, setSelectedTableId } = useFloorPlanStore();
  const accountMenuRef = useRef<HTMLDivElement | null>(null);
  const firstAccountMenuItemRef = useRef<HTMLButtonElement | null>(null);

  const restaurantsQuery = useQuery({
    queryKey: ["current-restaurants"],
    queryFn: () => apiFetch<{ restaurants: Restaurant[] }>("/api/restaurants/current")
  });
  const brandQuery = useQuery({
    queryKey: ["platform-brand"],
    queryFn: () =>
      apiFetch<{
        brand: {
          logoUrl: string;
          logoHeight: number;
          logoAlt: string;
        };
      }>("/api/platform-brand"),
    staleTime: 60_000
  });

  const restaurants = restaurantsQuery.data?.restaurants ?? [];
  const restaurant = restaurants[0];
  const dashboardLogoUrl = brandQuery.data?.brand.logoUrl ?? "/toquetop-logo.svg";
  const dashboardLogoAlt = brandQuery.data?.brand.logoAlt ?? "ToqueTop";
  const dashboardLogoHeight = brandQuery.data?.brand.logoHeight ?? 48;
  const minDashboardDate = operationalMinDate(restaurant?.timezone);
  const headerTodayDate = getZonedDateTimeParts(restaurant?.timezone || "Europe/Paris").date;
  const canGoToPreviousDay = selectedDate > minDashboardDate;

  useRestaurantSocket(restaurant?.id);

  useEffect(() => {
    if (selectedDate < minDashboardDate) {
      setSelectedDate(minDashboardDate);
    }
  }, [minDashboardDate, selectedDate]);

  useEffect(() => {
    if (!accountMenuOpen) {
      return;
    }

    firstAccountMenuItemRef.current?.focus();

    function handlePointerDown(event: MouseEvent | TouchEvent) {
      if (!accountMenuRef.current?.contains(event.target as Node)) {
        setAccountMenuOpen(false);
      }
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setAccountMenuOpen(false);
      }
    }

    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("touchstart", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("touchstart", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [accountMenuOpen]);

  function selectAccountMenuSection(targetSection: AdminSection) {
    setSection(targetSection);
    setAccountMenuOpen(false);
  }

  const tablesQuery = useQuery({
    queryKey: ["tables", restaurant?.id],
    enabled: Boolean(restaurant?.id),
    queryFn: () => apiFetch<{ tables: FloorTable[] }>(`/api/restaurants/${restaurant?.id}/tables`)
  });

  const reservationsQuery = useQuery({
    queryKey: ["reservations", restaurant?.id, selectedDate],
    enabled: Boolean(restaurant?.id),
    queryFn: () =>
      apiFetch<{ reservations: Reservation[] }>(`/api/restaurants/${restaurant?.id}/reservations?date=${selectedDate}`)
  });

  const clientsQuery = useQuery({
    queryKey: ["clients", restaurant?.id, clientSearch],
    enabled: Boolean(restaurant?.id),
    queryFn: () =>
      apiFetch<{ clients: Client[] }>(
        `/api/restaurants/${restaurant?.id}/clients${clientSearch ? `?search=${encodeURIComponent(clientSearch)}` : ""}`
      )
  });

  const waitlistQuery = useQuery({
    queryKey: ["waitlist", restaurant?.id, selectedDate],
    enabled: Boolean(restaurant?.id),
    queryFn: () => apiFetch<{ waitlist: WaitlistEntry[] }>(`/api/restaurants/${restaurant?.id}/waitlist?date=${selectedDate}`)
  });

  const chefQuery = useQuery({
    queryKey: ["chef-toque", restaurant?.id, selectedDate],
    enabled: Boolean(restaurant?.id),
    queryFn: () => apiFetch<{ insights: ChefInsight[] }>(`/api/restaurants/${restaurant?.id}/chef-toque?date=${selectedDate}`)
  });

  const eventsQuery = useQuery({
    queryKey: ["events", restaurant?.id],
    enabled: Boolean(restaurant?.id),
    queryFn: () => apiFetch<{ events: AuditEvent[] }>(`/api/restaurants/${restaurant?.id}/events?take=12`)
  });

  const rawTables = tablesQuery.data?.tables ?? restaurant?.tables ?? [];
  const reservations = reservationsQuery.data?.reservations ?? [];
  const clients = clientsQuery.data?.clients ?? [];
  const waitlist = waitlistQuery.data?.waitlist ?? [];
  const insights = chefQuery.data?.insights ?? [];
  const events = eventsQuery.data?.events ?? [];
  const settings = restaurant?.settings ?? {};
  const tables = useMemo(() => applyFloorPlanSettings(rawTables, settings), [rawTables, settings]);
  const selectedTable = tables.find((table) => table.id === selectedTableId);
  const selectedReservation = reservations.find((reservation) => reservation.id === selectedReservationId);
  const filteredReservations = restaurant
    ? reservations.filter((reservation) =>
        reservationMatchesService(reservation, selectedService, restaurant.openingHours, selectedDate)
      )
    : [];
  const activeReservations = filteredReservations.filter((reservation) => reservation.status !== "CANCELLED");
  const occupiedTableIds = new Set(activeReservations.map((reservation) => reservation.table?.id).filter(Boolean));
  const availableTables = tables.filter((table) => table.active && !occupiedTableIds.has(table.id));
  const availableTableIds = availableTables.map((table) => table.id);
  const availableCounts = capacityCounts(availableTables);
  const activeTableCount = tables.filter((table) => table.active).length;
  const occupancyRate = activeTableCount ? Math.round((occupiedTableIds.size / activeTableCount) * 100) : 0;
  const openingStatus = restaurant
    ? getRestaurantOpeningStatus(restaurant.openingHours, restaurant.timezone)
    : { label: "Chargement", tone: "soon" as const };
  const floorPlanModelUrl = floorPlanModelUrlFromSettings(settings);
  const floorPlan2dImageUrl = floorPlan2dImageUrlFromSettings(settings);

  const createReservationMutation = useMutation({
    mutationFn: (formData: FormData) => {
      const startTime = String(formData.get("startTime"));
      const endTime = minutesToTime(parseTimeToMinutes(startTime) + 120);

      return apiFetch<{ reservation: Reservation }>(`/api/restaurants/${restaurant?.id}/reservations`, {
        method: "POST",
        body: JSON.stringify({
          date: String(formData.get("date")),
          startTime,
          endTime,
          numberOfGuests: Number(formData.get("numberOfGuests")),
          tableId: String(formData.get("tableId") || "") || undefined,
          firstName: String(formData.get("firstName")),
          lastName: String(formData.get("lastName")),
          email: String(formData.get("email")),
          phone: String(formData.get("phone")),
          tablePreferences: tablePreferenceFromForm(formData),
          highChair: Boolean(formData.get("highChair")),
          birthday: Boolean(formData.get("birthday")),
          romanticDinner: Boolean(formData.get("romanticDinner")),
          notes: String(formData.get("notes") || "")
        })
      });
    },
    onSuccess: () => refreshLiveData()
  });

  const updateReservationMutation = useMutation({
    mutationFn: ({ reservationId, data }: { reservationId: string; data: Record<string, unknown> }) =>
      apiFetch<{ reservation: Reservation }>(`/api/reservations/${reservationId}`, {
        method: "PATCH",
        body: JSON.stringify(data)
      }),
    onSuccess: () => refreshLiveData()
  });

  const cancelReservationMutation = useMutation({
    mutationFn: (reservationId: string) =>
      apiFetch<void>(`/api/reservations/${reservationId}`, {
        method: "DELETE"
      }),
    onSuccess: () => refreshLiveData()
  });

  const updateTableMutation = useMutation({
    mutationFn: ({ tableId, data }: { tableId: string; data: Partial<FloorTable> }) =>
      apiFetch<{ table: FloorTable }>(`/api/tables/${tableId}`, {
        method: "PATCH",
        body: JSON.stringify(data)
      }),
    onSuccess: () => refreshLiveData()
  });

  const createBlockMutation = useMutation({
    mutationFn: (formData: FormData) =>
      apiFetch<{ block: unknown }>(`/api/tables/${selectedTableId}/blocks`, {
        method: "POST",
        body: JSON.stringify({
          date: String(formData.get("date")),
          startTime: String(formData.get("startTime")),
          endTime: String(formData.get("endTime")),
          reason: String(formData.get("reason")) as TableBlockReason,
          customerFirstName: String(formData.get("firstName") || ""),
          customerLastName: String(formData.get("lastName") || ""),
          customerEmail: String(formData.get("email") || ""),
          customerPhone: String(formData.get("phone") || ""),
          notes: String(formData.get("notes") || "")
        })
      }),
    onSuccess: () => refreshLiveData()
  });

  const createWaitlistMutation = useMutation({
    mutationFn: (formData: FormData) =>
      apiFetch<{ waitlistEntry: WaitlistEntry }>(`/api/restaurants/${restaurant?.id}/waitlist`, {
        method: "POST",
        body: JSON.stringify({
          date: String(formData.get("date")),
          requestedTime: String(formData.get("requestedTime") || ""),
          numberOfGuests: Number(formData.get("numberOfGuests")),
          firstName: String(formData.get("firstName")),
          lastName: String(formData.get("lastName")),
          email: String(formData.get("email") || ""),
          phone: String(formData.get("phone") || ""),
          notes: String(formData.get("notes") || ""),
          tablePreferences: tablePreferenceFromForm(formData)
        })
      }),
    onSuccess: () => refreshLiveData()
  });

  const createClientMutation = useMutation({
    mutationFn: (formData: FormData) =>
      apiFetch<{ client: Client }>(`/api/restaurants/${restaurant?.id}/clients`, {
        method: "POST",
        body: JSON.stringify({
          firstName: String(formData.get("firstName")),
          lastName: String(formData.get("lastName")),
          email: String(formData.get("email") || ""),
          phone: String(formData.get("phone") || ""),
          birthday: String(formData.get("birthday") || ""),
          allergies: String(formData.get("allergies") || ""),
          preferences: String(formData.get("preferences") || "")
            .split(",")
            .map((value) => value.trim())
            .filter(Boolean),
          internalNotes: String(formData.get("internalNotes") || ""),
          vip: Boolean(formData.get("vip")),
          noShowRisk: Number(formData.get("noShowRisk") || 0)
        })
      }),
    onSuccess: () => refreshLiveData()
  });

  function refreshLiveData() {
    setModal(null);
    queryClient.invalidateQueries({ queryKey: ["reservations", restaurant?.id] });
    queryClient.invalidateQueries({ queryKey: ["tables", restaurant?.id] });
    queryClient.invalidateQueries({ queryKey: ["clients", restaurant?.id] });
    queryClient.invalidateQueries({ queryKey: ["waitlist", restaurant?.id] });
    queryClient.invalidateQueries({ queryKey: ["chef-toque", restaurant?.id] });
    queryClient.invalidateQueries({ queryKey: ["events", restaurant?.id] });
  }

  function submitForm(mutation: { mutate: (formData: FormData) => void }) {
    return (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      mutation.mutate(new FormData(event.currentTarget));
    };
  }

  function handleChefSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const question = chefPrompt.trim();

    if (!question) {
      return;
    }

    const serviceLabel = selectedService === "lunch" ? "midi" : "soir";
    const urgentInsight = insights.find((insight) => insight.level === "critical") ?? insights.find((insight) => insight.level === "warning");
    const waitingCount = waitlist.filter((entry) => entry.status === "WAITING").length;
    const nextReservation = [...activeReservations].sort((first, second) => first.startTime.localeCompare(second.startTime))[0];
    const answer = [
      `Pour le ${serviceLabel} du ${formatDate(selectedDate)}, je vois ${activeReservations.length} réservation(s) active(s) et ${availableTableIds.length} table(s) libre(s).`,
      `Détail tables libres : ${availableCounts.two} table(s) de 2, ${availableCounts.four} table(s) de 4, ${availableCounts.sixPlus} table(s) de 6+.`,
      waitingCount > 0 ? `La liste d’attente contient ${waitingCount} demande(s) à surveiller.` : "La liste d’attente est vide pour le moment.",
      nextReservation ? `Prochaine réservation : ${nextReservation.startTime}, ${reservationGuestName(nextReservation)}, ${nextReservation.numberOfGuests} couvert(s).` : "Aucune réservation active n’est prévue sur ce service.",
      urgentInsight ? `Point d’attention : ${urgentInsight.title}. ${urgentInsight.message}` : "Je ne détecte pas d’alerte prioritaire sur ce service."
    ].join("\n");

    setChefMessages((messages) => [
      ...messages,
      { role: "user", content: question },
      { role: "assistant", content: answer }
    ]);
    setChefPrompt("");
  }

  if (!restaurant) {
    const hasRestaurantLoadError = restaurantsQuery.isError;

    return (
      <main className="grid min-h-screen place-items-center bg-linen px-4 py-10">
        <div className="w-full max-w-xl rounded-lg border border-ink/10 bg-white p-8 text-center shadow-soft">
          <img
            alt={dashboardLogoAlt}
            className="mx-auto w-auto object-contain"
            src={dashboardLogoUrl}
            style={{ height: dashboardLogoHeight, maxWidth: 260 }}
          />
          {restaurantsQuery.isLoading ? (
            <div className="mt-8">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-sage text-moss">
                <span className="h-6 w-6 animate-spin rounded-full border-2 border-moss/20 border-t-moss" />
              </div>
              <h1 className="mt-5 text-2xl font-black text-ink">Dashboard Live</h1>
              <p className="mt-2 text-sm font-semibold text-ink/60">
                Chargement du dashboard restaurant
                <span className="ml-1 inline-flex w-6 justify-start">
                  <span className="animate-bounce">.</span>
                  <span className="animate-bounce [animation-delay:120ms]">.</span>
                  <span className="animate-bounce [animation-delay:240ms]">.</span>
                </span>
              </p>
              <div className="mt-6 h-1.5 overflow-hidden rounded-full bg-linen">
                <div className="dashboard-loading-bar h-full w-1/3 rounded-full bg-moss" />
              </div>
            </div>
          ) : hasRestaurantLoadError ? (
            <div className="mt-4 rounded-md border border-amber-200 bg-amber-50 p-4 text-left">
              <p className="text-sm font-black text-amber-900">Impossible de charger les restaurants pour le moment.</p>
              <p className="mt-2 text-sm font-semibold leading-6 text-amber-800">
                {restaurantsQuery.error instanceof Error
                  ? restaurantsQuery.error.message
                  : "Le dashboard est bien déployé, mais l’API restaurants ne répond pas."}
              </p>
              <button
                className="mt-4 rounded-md bg-ink px-4 py-2 text-sm font-black text-white transition hover:bg-moss"
                type="button"
                onClick={() => restaurantsQuery.refetch()}
              >
                Réessayer
              </button>
            </div>
          ) : (
            <p className="mt-2 text-sm font-semibold text-ink/60">Créez un restaurant pour commencer.</p>
          )}
        </div>
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-linen text-ink">
      <header className="fixed inset-x-0 top-0 z-40 border-b border-ink/10 bg-white/90 backdrop-blur">
        <div className="grid h-16 grid-cols-[auto_1fr_auto] items-center gap-4 px-4">
          <div className="flex items-center gap-3">
            <img
              alt={dashboardLogoAlt}
              className="h-12 w-auto object-contain"
              src={dashboardLogoUrl}
              style={{ maxWidth: 260 }}
            />
          </div>
          <div className="text-center">
            <div className="inline-flex items-center justify-center gap-2">
              <span aria-hidden="true" className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-500 opacity-70" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-red-600" />
              </span>
              <p className="text-sm font-black uppercase tracking-[0.18em] text-moss">Dashboard Live</p>
              <div className="group relative inline-flex">
                <button
                  aria-describedby="dashboard-live-help"
                  className="grid h-7 w-7 place-items-center rounded-full text-moss transition hover:bg-sage focus:outline-none focus:ring-2 focus:ring-moss/30"
                  type="button"
                >
                  <Radio className="h-4 w-4" />
                  <span className="sr-only">Information sur le mode live</span>
                </button>
                <div
                  className="pointer-events-none absolute left-1/2 top-9 z-50 w-72 -translate-x-1/2 rounded-md border border-ink/10 bg-white p-3 text-left text-xs font-semibold leading-5 text-ink/70 opacity-0 shadow-soft transition group-hover:opacity-100 group-focus-within:opacity-100"
                  id="dashboard-live-help"
                  role="tooltip"
                >
                  Le mode live permet d’avoir accès en temps réel aux réservations, annulations et changements de plan.
                  Les données se mettent à jour automatiquement.
                </div>
              </div>
            </div>
            <p className="text-xs font-semibold text-ink/55">{formatDate(headerTodayDate)}</p>
          </div>
          <div className="relative flex items-center gap-2 text-sm font-bold" ref={accountMenuRef}>
            <span className="hidden max-w-[180px] truncate sm:inline">{restaurant.name}</span>
            <button
              aria-controls="dashboard-account-menu"
              aria-expanded={accountMenuOpen}
              aria-haspopup="menu"
              aria-label="Ouvrir le menu du restaurant"
              className="grid h-10 w-10 place-items-center rounded-full bg-sage text-moss transition hover:bg-moss hover:text-white focus:outline-none focus:ring-2 focus:ring-moss/30"
              type="button"
              onClick={() => setAccountMenuOpen((current) => !current)}
            >
              <span aria-hidden="true" className="flex flex-col items-center gap-1">
                <span className="block h-1 w-5 rounded-full border border-current" />
                <span className="block h-1 w-5 rounded-full border border-current" />
                <span className="block h-1 w-5 rounded-full border border-current" />
              </span>
            </button>
            {accountMenuOpen ? (
              <div
                aria-label="Menu du restaurant"
                className="absolute right-0 top-12 z-50 w-64 overflow-hidden rounded-lg border border-ink/10 bg-white p-2 text-left shadow-soft"
                id="dashboard-account-menu"
                role="menu"
              >
                <button
                  ref={firstAccountMenuItemRef}
                  className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm font-bold text-ink/75 transition hover:bg-linen focus:bg-linen focus:outline-none"
                  role="menuitem"
                  type="button"
                  onClick={() => selectAccountMenuSection("general")}
                >
                  <UserRound className="h-4 w-4" />
                  Profil
                </button>
                <button
                  className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm font-bold text-ink/75 transition hover:bg-linen focus:bg-linen focus:outline-none"
                  role="menuitem"
                  type="button"
                  onClick={() => selectAccountMenuSection("general")}
                >
                  <Settings className="h-4 w-4" />
                  Configurations
                </button>
                <button
                  className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm font-bold text-ink/75 transition hover:bg-linen focus:bg-linen focus:outline-none"
                  role="menuitem"
                  type="button"
                  onClick={() => selectAccountMenuSection("subscription")}
                >
                  <CreditCard className="h-4 w-4" />
                  Abonnement
                </button>
                <button
                  className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm font-bold text-ink/75 transition hover:bg-linen focus:bg-linen focus:outline-none"
                  role="menuitem"
                  type="button"
                  onClick={() => selectAccountMenuSection("guide")}
                >
                  <LifeBuoy className="h-4 w-4" />
                  Aide
                </button>
                <div className="my-2 border-t border-ink/10" />
                <button
                  className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm font-black text-red-700/85 transition hover:bg-red-50 focus:bg-red-50 focus:outline-none"
                  role="menuitem"
                  type="button"
                  onClick={() => signOut({ callbackUrl: "/login" })}
                >
                  <LogOut className="h-4 w-4" />
                  Se déconnecter
                </button>
              </div>
            ) : null}
          </div>
        </div>
      </header>

      <aside
        className={clsx(
          "fixed bottom-0 left-0 top-16 z-30 border-r border-ink/10 bg-white transition-all",
          sidebarCollapsed ? "w-16" : "w-72 shadow-soft"
        )}
      >
        <button
          className="flex h-12 w-full items-center justify-center border-b border-ink/10 text-ink/70 hover:bg-sage/50"
          type="button"
          onClick={() => setSidebarCollapsed((current) => !current)}
        >
          {sidebarCollapsed ? <PanelLeftOpen className="h-5 w-5" /> : <PanelLeftClose className="h-5 w-5" />}
          <span className="sr-only">Rétracter le menu</span>
        </button>
        <nav className="space-y-1 p-2">
          {menuItems.map((item) => (
            <div key={item.id}>
              <button
                className={clsx(
                  "flex w-full items-center gap-3 rounded-md px-3 py-2 text-left text-sm font-bold transition hover:bg-sage/60",
                  section === item.id ? "bg-moss text-white hover:bg-moss" : "text-ink/70"
                )}
                type="button"
                onClick={() => setSection(item.id)}
              >
                {item.icon}
                {sidebarCollapsed ? null : <span>{item.label}</span>}
              </button>
              {item.id === "general" && section === "general" && !sidebarCollapsed ? (
                <div className="mt-1 space-y-1 pl-7">
                  {generalSubMenu.map((subItem) => (
                    <button
                      key={subItem}
                      className={clsx(
                        "flex w-full items-center rounded-md px-3 py-1.5 text-left text-xs font-black transition hover:bg-sage/60",
                        section === "general" && generalPage === subItem ? "bg-sage text-moss" : "text-ink/55"
                      )}
                      type="button"
                      onClick={() => {
                        setSection("general");
                        setGeneralPage(subItem);
                      }}
                    >
                      {subItem}
                    </button>
                  ))}
                </div>
              ) : null}
            </div>
          ))}
        </nav>
      </aside>

      <main className={clsx("pt-16 transition-[padding]", section === "dashboard" || sidebarCollapsed ? "pl-16" : "pl-72")}>
        <div
          className={clsx(
            "p-4 transition-[padding]",
            section === "dashboard" ? "grid gap-4 xl:grid-cols-[minmax(0,1fr)_420px]" : "flex justify-center"
          )}
        >
          <section className={clsx("space-y-4", section !== "dashboard" ? "w-full max-w-5xl" : "")}>
            {section === "dashboard" ? (
              <>
                <div className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h1 className="text-xl font-black text-ink">Tableau de bord</h1>
                      <p className="text-sm font-semibold capitalize text-ink/55">{formatLongDate(selectedDate)}</p>
                    </div>
                    <div className="flex flex-wrap items-end gap-2">
                      <div className="grid justify-items-center gap-1">
                        <span className="text-center text-xs font-black uppercase tracking-[0.12em] text-ink/45">Date</span>
                        <div className="flex items-center gap-2">
                          <button
                            className="grid h-10 w-10 place-items-center rounded-md border border-ink/10 bg-linen text-ink/70 transition hover:bg-sage disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-linen"
                            disabled={!canGoToPreviousDay}
                            type="button"
                            onClick={() => {
                              const previousDate = addDaysToDateString(selectedDate, -1);
                              setSelectedDate(previousDate < minDashboardDate ? minDashboardDate : previousDate);
                            }}
                          >
                            <ChevronLeft className="h-4 w-4" />
                            <span className="sr-only">Jour précédent</span>
                          </button>
                          <input
                            className="control h-10 w-40"
                            min={minDashboardDate}
                            type="date"
                            value={selectedDate}
                            onChange={(event) => {
                              const nextDate = event.target.value;
                              setSelectedDate(nextDate < minDashboardDate ? minDashboardDate : nextDate);
                            }}
                          />
                          <button
                            className="grid h-10 w-10 place-items-center rounded-md border border-ink/10 bg-linen text-ink/70 transition hover:bg-sage"
                            type="button"
                            onClick={() => setSelectedDate(addDaysToDateString(selectedDate, 1))}
                          >
                            <ChevronRight className="h-4 w-4" />
                            <span className="sr-only">Jour suivant</span>
                          </button>
                        </div>
                      </div>
                      <div className="grid justify-items-center gap-1">
                        <span className="text-center text-xs font-black uppercase tracking-[0.12em] text-ink/45">Service</span>
                        <Segmented
                          options={[
                            { value: "lunch", label: "Midi" },
                            { value: "dinner", label: "Soir" }
                          ]}
                          value={selectedService}
                          onChange={(value) => setSelectedService(value as ServiceFilter)}
                        />
                      </div>
                      <div className="grid justify-items-center gap-1">
                        <span className="text-center text-xs font-black uppercase tracking-[0.12em] text-ink/45">Statut</span>
                        <span className={clsx("inline-flex h-10 items-center gap-2 rounded-md border px-3 text-sm font-black", openingStatusClass(openingStatus.tone))}>
                          <span className="h-2.5 w-2.5 rounded-full bg-current" />
                          {openingStatus.label}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-4">
                  <Metric label="Réservations" value={activeReservations.length.toString()} />
                  <Metric label="Taux de remplissage" value={`${occupancyRate}%`} />
                  <Metric
                    label="Tables libres"
                    value={`${availableTableIds.length}/${activeTableCount}`}
                    detail={
                      <>
                        <span>Tables de 2 : {availableCounts.two}</span>
                        <span>Tables de 4 : {availableCounts.four}</span>
                        <span>Tables 6+ : {availableCounts.sixPlus}</span>
                      </>
                    }
                  />
                  <Metric label="Liste d’attente" value={waitlist.filter((entry) => entry.status === "WAITING").length.toString()} />
                </div>

                <div className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
                  <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h2 className="text-xl font-black text-ink">Plan de salle live</h2>
                      <p className="text-sm font-semibold text-ink/55">
                        Service {selectedService === "lunch" ? "midi" : "soir"} · {formatDate(selectedDate)}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <Segmented
                        options={[
                          { value: "2d", label: "2D" },
                          { value: "3d", label: "3D" }
                        ]}
                        value={floorViewMode}
                        onChange={(value) => setFloorViewMode(value as "2d" | "3d")}
                      />
                      <label className="flex items-center gap-2 text-xs font-bold text-ink/60">
                        Zoom
                        <input
                          className="w-28 accent-moss"
                          max="1.8"
                          min="0.7"
                          step="0.05"
                          type="range"
                          value={floorZoom}
                          onChange={(event) => setFloorZoom(Number(event.target.value))}
                        />
                      </label>
                    </div>
                  </div>
                  <div className="h-[520px] overflow-hidden rounded-lg border border-ink/10 bg-linen">
                    <FloorPlan
                      availableTableIds={availableTableIds}
                      backgroundImageUrl={floorPlan2dImageUrl}
                      layoutLocked={restaurant.layoutLocked}
                      mode="admin"
                      modelUrl={floorPlanModelUrl}
                      selectedTableId={selectedTableId}
                      tables={tables}
                      viewMode={floorViewMode}
                      zoom={floorZoom}
                      onMove={(tableId, position) => updateTableMutation.mutate({ tableId, data: position })}
                      onSelect={(table) => setSelectedTableId(table.id)}
                      onZoomChange={setFloorZoom}
                    />
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs font-bold text-ink/60">
                    <span className="rounded-full bg-moss/10 px-3 py-1 text-moss">Disponible</span>
                    <span className="rounded-full bg-amber-50 px-3 py-1 text-amber-700">Occupée</span>
                    <span className="rounded-full bg-red-50 px-3 py-1 text-red-700">Bloquée / indisponible</span>
                    {selectedTable ? <span>Table sélectionnée : {selectedTable.label} · {selectedTable.capacity} couverts</span> : null}
                  </div>
                </div>

                <div className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
                  <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h2 className="text-base font-black">Réservations</h2>
                      <p className="text-xs font-semibold text-ink/55">
                        {selectedService === "lunch" ? "Midi" : "Soir"} · {formatDate(selectedDate)}
                      </p>
                    </div>
                    <Segmented
                      options={[
                        { value: "list", label: "Liste" },
                        { value: "calendar", label: "Calendrier" },
                        { value: "timeline", label: "Timeline" }
                      ]}
                      value={reservationView}
                      onChange={(value) => setReservationView(value as ReservationView)}
                    />
                  </div>
                  <ReservationsPanel
                    reservations={filteredReservations}
                    selectedReservationId={selectedReservationId}
                    view={reservationView}
                    onCancel={(reservationId) => cancelReservationMutation.mutate(reservationId)}
                    onEdit={(reservationId) => {
                      setSelectedReservationId(reservationId);
                      setModal("editReservation");
                    }}
                    onSelect={setSelectedReservationId}
                  />
                </div>
              </>
            ) : null}

            {section === "guide" ? <GuidePanel /> : null}
            {section === "general" ? (
              <GeneralPanel
                activePage={generalPage}
                restaurant={restaurant}
                tableCount={tables.length}
              />
            ) : null}
            {section === "reservations" ? (
              <div className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-black">Réservations</h2>
                    <p className="text-sm font-semibold text-ink/55">{formatDate(selectedDate)}</p>
                  </div>
                  <input
                    className="control h-10 w-36"
                    min={minDashboardDate}
                    type="date"
                    value={selectedDate}
                    onChange={(event) => {
                      const nextDate = event.target.value;
                      setSelectedDate(nextDate < minDashboardDate ? minDashboardDate : nextDate);
                    }}
                  />
                </div>
                <Segmented
                  options={[
                    { value: "list", label: "Liste" },
                    { value: "calendar", label: "Calendrier" },
                    { value: "timeline", label: "Timeline" }
                  ]}
                  value={reservationView}
                  onChange={(value) => setReservationView(value as ReservationView)}
                />
                <ReservationsPanel
                  reservations={reservations}
                  selectedReservationId={selectedReservationId}
                  view={reservationView}
                  onCancel={(reservationId) => cancelReservationMutation.mutate(reservationId)}
                  onEdit={(reservationId) => {
                    setSelectedReservationId(reservationId);
                    setModal("editReservation");
                  }}
                  onSelect={setSelectedReservationId}
                />
              </div>
            ) : null}
            {section === "crm" ? (
              <CrmPanel clients={clients} clientSearch={clientSearch} setClientSearch={setClientSearch} onCreate={() => setModal("client")} />
            ) : null}
            {section === "notifications" ? <TemplatesPanel restaurantId={restaurant.id} /> : null}
            {!["dashboard", "guide", "general", "reservations", "crm", "notifications"].includes(section) ? (
              <PlaceholderPanel section={menuItems.find((item) => item.id === section)?.label ?? "Section"} />
            ) : null}
          </section>

          {section === "dashboard" ? (
          <aside className="flex flex-col gap-4">
            <div className="order-2 rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
              <div className="mb-3 flex items-center justify-between gap-3">
                <h2 className="text-base font-black">Actions rapides</h2>
                <Sparkles className="h-4 w-4 text-moss" />
              </div>
              <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-1">
                <QuickAction icon={<Plus className="h-4 w-4" />} label="Ajouter réservation" onClick={() => setModal("createReservation")} />
                <QuickAction
                  disabled={!selectedReservation}
                  icon={<Table2 className="h-4 w-4" />}
                  label="Attribuer table"
                  onClick={() =>
                    selectedReservation && selectedTable
                      ? updateReservationMutation.mutate({
                          reservationId: selectedReservation.id,
                          data: { tableId: selectedTable.id }
                        })
                      : undefined
                  }
                />
                <QuickAction disabled={!selectedTable} icon={<Clock3 className="h-4 w-4" />} label="Bloquer table" onClick={() => setModal("blockTable")} />
                <QuickAction
                  disabled={!selectedReservation}
                  icon={<Check className="h-4 w-4" />}
                  label="Client arrivé"
                  onClick={() =>
                    selectedReservation
                      ? updateReservationMutation.mutate({
                          reservationId: selectedReservation.id,
                          data: { arrivedAt: "now" }
                        })
                      : undefined
                  }
                />
                <QuickAction
                  disabled={!selectedReservation}
                  icon={<Phone className="h-4 w-4" />}
                  label="Contacter client"
                  onClick={() => {
                    const phone = selectedReservation?.guestPhone;
                    if (phone) window.location.href = `tel:${phone}`;
                  }}
                />
                <QuickAction icon={<Users className="h-4 w-4" />} label="Ajouter waitlist" onClick={() => setModal("waitlist")} />
              </div>
            </div>

            <div className="order-1 rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
              <div className="mb-3 flex items-center gap-2">
                <Bot className="h-5 w-5 text-moss" />
                <h2 className="text-base font-black">ToqueChef</h2>
              </div>
              <div className="space-y-2">
                {insights.length === 0 ? (
                  <p className="rounded-md bg-linen p-3 text-sm font-semibold text-ink/60">Aucune alerte pour le moment.</p>
                ) : (
                  insights.map((insight) => (
                    <article key={insight.id} className={clsx("rounded-md border p-3", insightClass(insight.level))}>
                      <h3 className="text-sm font-black">{insight.title}</h3>
                      <p className="mt-1 text-xs font-semibold leading-5">{insight.message}</p>
                    </article>
                  ))
                )}
              </div>
              <form className="mt-4 border-t border-ink/10 pt-4" onSubmit={handleChefSubmit}>
                <label className="text-xs font-black uppercase tracking-[0.12em] text-ink/45" htmlFor="chef-toque-prompt">
                  Demander à ToqueChef
                </label>
                <textarea
                  className="control mt-2 min-h-20 w-full resize-none text-sm"
                  id="chef-toque-prompt"
                  placeholder="Ex : Quelle table proposer à un client VIP de 4 personnes ce soir ?"
                  value={chefPrompt}
                  onChange={(event) => setChefPrompt(event.target.value)}
                />
                <button className="primary-button mt-2 w-full" type="submit">
                  <Bot className="h-4 w-4" />
                  Demander
                </button>
              </form>
              <div className="mt-3 max-h-72 space-y-2 overflow-auto pr-1">
                {chefMessages.map((message, index) => (
                  <div
                    key={`${message.role}-${index}`}
                    className={clsx(
                      "rounded-md p-3 text-xs font-semibold leading-5",
                      message.role === "user" ? "bg-moss text-white" : "bg-linen text-ink/70"
                    )}
                  >
                    <p className="mb-1 font-black">{message.role === "user" ? "Vous" : "ToqueChef"}</p>
                    <p className="whitespace-pre-line">{message.content}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="order-3 rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
              <h2 className="text-base font-black">Activité récente</h2>
              <div className="mt-3 space-y-2">
                {events.map((event) => (
                  <div key={event.id} className="rounded-md bg-linen p-3 text-xs font-semibold text-ink/65">
                    <p className="font-black text-ink">{event.action}</p>
                    <p>{event.entityType} · {new Date(event.createdAt).toLocaleString("fr-FR")}</p>
                  </div>
                ))}
                {events.length === 0 ? <p className="text-sm font-semibold text-ink/55">Aucun événement récent.</p> : null}
              </div>
            </div>
          </aside>
          ) : null}
        </div>
      </main>

      {modal === "createReservation" ? (
        <DashboardModal title="Ajouter une réservation" onClose={() => setModal(null)}>
          <ReservationForm
            defaultDate={selectedDate}
            defaultTableId={selectedTableId}
            tables={tables}
            onSubmit={submitForm(createReservationMutation)}
          />
        </DashboardModal>
      ) : null}

      {modal === "editReservation" && selectedReservation ? (
        <DashboardModal title="Modifier la réservation" onClose={() => setModal(null)}>
          <form
            className="grid gap-3"
            onSubmit={(event) => {
              event.preventDefault();
              const formData = new FormData(event.currentTarget);
              updateReservationMutation.mutate({
                reservationId: selectedReservation.id,
                data: {
                  status: String(formData.get("status")),
                  tableId: String(formData.get("tableId") || "") || null,
                  notes: String(formData.get("notes") || "")
                }
              });
            }}
          >
            <SelectField defaultValue={selectedReservation.status} label="Statut" name="status" options={["PENDING", "CONFIRMED", "CANCELLED"]} />
            <SelectField
              defaultValue={selectedReservation.table?.id ?? ""}
              label="Table"
              name="tableId"
              options={["", ...tables.map((table) => table.id)]}
              render={(value) => tables.find((table) => table.id === value)?.label ?? "Aucune table"}
            />
            <label className="text-sm font-bold">
              Notes
              <textarea className="control mt-1 min-h-24 w-full" defaultValue={selectedReservation.notes ?? ""} name="notes" />
            </label>
            <button className="primary-button w-full" type="submit">Enregistrer</button>
          </form>
        </DashboardModal>
      ) : null}

      {modal === "blockTable" ? (
        <DashboardModal title="Bloquer une table" onClose={() => setModal(null)}>
          <form className="grid gap-3" onSubmit={submitForm(createBlockMutation)}>
            <p className="rounded-md bg-linen p-3 text-sm font-bold">Table : {selectedTable?.label ?? "Aucune table sélectionnée"}</p>
            <InputField defaultValue={selectedDate} label="Date" name="date" type="date" />
            <SelectField defaultValue="12:00" label="Début" name="startTime" options={timeOptions} />
            <SelectField defaultValue="14:00" label="Fin" name="endTime" options={timeOptions} />
            <SelectField defaultValue="ADMIN" label="Raison" name="reason" options={["ADMIN", "MAINTENANCE", "EVENT"]} />
            <div className="grid gap-3 sm:grid-cols-2">
              <InputField label="Prénom client" name="firstName" />
              <InputField label="Nom client" name="lastName" />
            </div>
            <InputField label="Email" name="email" type="email" />
            <InputField label="Téléphone" name="phone" />
            <label className="text-sm font-bold">
              Note
              <textarea className="control mt-1 min-h-20 w-full" name="notes" />
            </label>
            <button className="primary-button w-full" disabled={!selectedTableId} type="submit">Bloquer la table</button>
          </form>
        </DashboardModal>
      ) : null}

      {modal === "waitlist" ? (
        <DashboardModal title="Ajouter à la liste d’attente" onClose={() => setModal(null)}>
          <WaitlistForm defaultDate={selectedDate} onSubmit={submitForm(createWaitlistMutation)} />
        </DashboardModal>
      ) : null}

      {modal === "client" ? (
        <DashboardModal title="Créer une fiche client" onClose={() => setModal(null)}>
          <ClientForm onSubmit={submitForm(createClientMutation)} />
        </DashboardModal>
      ) : null}
    </div>
  );
}

function Metric({ detail, label, value }: { detail?: ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
      <p className="text-xs font-black uppercase tracking-[0.14em] text-ink/45">{label}</p>
      <div className="mt-2 flex items-center gap-2">
        <p className="text-3xl font-black text-ink">{value}</p>
        {detail ? (
          <div className="group relative inline-flex">
            <button
              aria-label={`Détail ${label}`}
              className="grid h-7 w-7 place-items-center rounded-full text-moss transition hover:bg-sage focus:outline-none focus:ring-2 focus:ring-moss/30"
              type="button"
            >
              <Info className="h-4 w-4" />
            </button>
            <div
              className="pointer-events-none absolute left-1/2 top-9 z-30 grid w-44 -translate-x-1/2 gap-1 rounded-md border border-ink/10 bg-white p-3 text-xs font-black leading-5 text-ink/65 opacity-0 shadow-soft transition group-hover:opacity-100 group-focus-within:opacity-100"
              role="tooltip"
            >
              {detail}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function Segmented({
  options,
  value,
  onChange
}: {
  options: Array<{ value: string; label: string }>;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className="inline-grid grid-flow-col rounded-md border border-ink/10 bg-linen p-1">
      {options.map((option) => (
        <button
          key={option.value}
          className={clsx(
            "rounded px-3 py-1.5 text-xs font-black transition",
            value === option.value ? "bg-white text-ink shadow-sm" : "text-ink/55 hover:text-ink"
          )}
          type="button"
          onClick={() => onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

function QuickAction({ disabled, icon, label, onClick }: { disabled?: boolean; icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      className="secondary-button justify-start disabled:opacity-40"
      disabled={disabled}
      type="button"
      onClick={onClick}
    >
      {icon}
      {label}
    </button>
  );
}

function ReservationsPanel({
  reservations,
  selectedReservationId,
  view,
  onCancel,
  onEdit,
  onSelect
}: {
  reservations: Reservation[];
  selectedReservationId: string | null;
  view: ReservationView;
  onCancel: (reservationId: string) => void;
  onEdit: (reservationId: string) => void;
  onSelect: (reservationId: string) => void;
}) {
  const sortedReservations = [...reservations].sort((first, second) => first.startTime.localeCompare(second.startTime));

  if (sortedReservations.length === 0) {
    return <p className="mt-3 rounded-md bg-linen p-3 text-sm font-semibold text-ink/60">Aucune réservation sur cette date.</p>;
  }

  return (
    <div className={clsx("mt-3 space-y-2", view === "calendar" ? "grid grid-cols-1 gap-2 space-y-0" : "")}>
      {sortedReservations.map((reservation) => (
        <article
          key={reservation.id}
          className={clsx(
            "rounded-md border p-3 transition",
            selectedReservationId === reservation.id ? "border-moss bg-moss/5" : "border-ink/10 bg-linen/70"
          )}
        >
          <button className="w-full text-left" type="button" onClick={() => onSelect(reservation.id)}>
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm font-black">{reservation.startTime} · {reservationGuestName(reservation)}</p>
              <span className={clsx("rounded-full border px-2 py-0.5 text-[11px] font-black", statusClass(reservation.status))}>
                {statusLabel(reservation.status)}
              </span>
            </div>
            <p className="mt-1 text-xs font-semibold text-ink/60">
              {reservation.numberOfGuests} couverts · {reservation.table?.label ?? "Sans table"} · Réf. {reservation.referenceCode ?? "—"}
            </p>
            {view === "timeline" ? (
              <div className="mt-2 h-2 rounded-full bg-white">
                <div className="h-2 rounded-full bg-moss" style={{ width: `${Math.min(100, reservation.numberOfGuests * 12)}%` }} />
              </div>
            ) : null}
          </button>
          <div className="mt-3 flex flex-wrap gap-2">
            <button className="secondary-button h-8 text-xs" type="button" onClick={() => onEdit(reservation.id)}>Modifier</button>
            <button className="secondary-button h-8 text-xs text-red-700" type="button" onClick={() => onCancel(reservation.id)}>Annuler</button>
            {reservation.guestEmail ? (
              <a className="secondary-button h-8 text-xs" href={`mailto:${reservation.guestEmail}`}>
                <Mail className="h-3.5 w-3.5" />
                Email
              </a>
            ) : null}
          </div>
        </article>
      ))}
    </div>
  );
}

function GuidePanel() {
  return (
    <section className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
      <h2 className="text-lg font-black">Guide de configuration</h2>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {setupChecklist.map((item, index) => (
          <label key={item} className="flex items-center gap-3 rounded-md bg-linen p-3 text-sm font-bold">
            <input className="h-4 w-4 accent-moss" type="checkbox" defaultChecked={index < 3} />
            {item}
          </label>
        ))}
      </div>
    </section>
  );
}

function GeneralPanel({
  activePage,
  restaurant,
  tableCount
}: {
  activePage: GeneralPage;
  restaurant: Restaurant;
  tableCount: number;
}) {
  return (
    <section className="rounded-lg border border-ink/10 bg-white p-5 shadow-soft">
      <GeneralPageContent page={activePage} restaurant={restaurant} tableCount={tableCount} />
    </section>
  );
}

function settingString(settings: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const value = settings[key];
    if (typeof value === "string" && value.trim()) {
      return value;
    }
  }

  return "";
}

function GeneralPageContent({ page, restaurant, tableCount }: { page: GeneralPage; restaurant: Restaurant; tableCount: number }) {
  const reservationDuration = String(restaurant.settings.reservationDurationMinutes ?? 120);
  const oneReservationPerService = Boolean(restaurant.settings.oneReservationPerTablePerService);
  const minimumAdvanceBooking = Boolean(restaurant.settings.minimumAdvanceBookingEnabled ?? true);
  const restaurantEmail = settingString(restaurant.settings, ["email", "mail", "contactEmail", "restaurantEmail"]);
  const postalCode = settingString(restaurant.settings, ["postalCode", "zipCode"]);
  const city = settingString(restaurant.settings, ["city"]);
  const country = settingString(restaurant.settings, ["country"]) || "France";
  const language = settingString(restaurant.settings, ["language", "locale"]) || "fr";
  const timeFormat = settingString(restaurant.settings, ["timeFormat"]) || "24h";

  if (page === "Restaurant") {
    return (
      <div className="space-y-6">
        <PanelHeader title="Configurations" description="Informations principales utilisées pour identifier le restaurant, afficher ses coordonnées et adapter les réglages régionaux." />

        <div>
          <h3 className="text-sm font-black uppercase tracking-[0.14em] text-moss">Le lieu</h3>
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            <InputField defaultValue={restaurant.name} label="Nom du restaurant" name="name" />
            <InputField defaultValue={restaurant.phone ?? ""} label="Téléphone" name="phone" />
            <InputField defaultValue={restaurantEmail} label="Mail" name="mail" type="email" />
            <InputField defaultValue={restaurant.address ?? ""} label="Adresse" name="address" />
            <div className="grid gap-3 sm:grid-cols-2">
              <InputField defaultValue={postalCode} label="Code postal" name="postalCode" />
              <InputField defaultValue={city} label="Ville" name="city" />
            </div>
            <InputField defaultValue={country} label="Pays" name="country" />
          </div>
        </div>

        <div>
          <h3 className="text-sm font-black uppercase tracking-[0.14em] text-moss">Paramètres régionaux</h3>
          <div className="mt-3 grid gap-3 md:grid-cols-3">
            <SelectField
              defaultValue={language}
              label="Langue standard"
              name="language"
              options={["fr", "en"]}
              render={(value) => value === "fr" ? "Français" : "Anglais"}
            />
            <SelectField
              defaultValue={restaurant.timezone}
              label="Fuseau horaire"
              name="timezone"
              options={["Europe/Paris", "Europe/London", "Europe/Madrid", "Europe/Rome", "America/New_York", "America/Los_Angeles"]}
            />
            <SelectField
              defaultValue={timeFormat}
              label="Format d’heure"
              name="timeFormat"
              options={["24h", "12h"]}
              render={(value) => value === "24h" ? "24 heures" : "12 heures AM/PM"}
            />
          </div>
        </div>
      </div>
    );
  }

  if (page === "Heures d’ouverture") {
    return <OpeningHoursPanel restaurant={restaurant} />;
  }

  if (page === "Congés") {
    return <ClosuresPanel restaurant={restaurant} />;
  }

  if (page === "Tables et salles") {
    return (
      <div>
        <PanelHeader title="Tables et salles" description="Plan de salle, zones, capacités et verrouillage des modifications." />
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <SettingCard label="Tables actives" value={tableCount.toString()} />
          <SettingCard label="Plan verrouillé" value={restaurant.layoutLocked ? "Oui" : "Non"} />
          <SettingCard label="Zones" value="Salle, terrasse, VIP" />
        </div>
        <p className="mt-4 rounded-md bg-linen p-3 text-sm font-semibold text-ink/60">
          La modification visuelle du plan reste disponible depuis le Plan de salle live.
        </p>
      </div>
    );
  }

  if (page === "Paramètres de réservation") {
    return (
      <div>
        <PanelHeader title="Paramètres de réservation" description="Règles appliquées aux créneaux, disponibilités et réservations automatiques." />
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <label className="text-sm font-bold">
            Durée d’une réservation
            <select className="control mt-1 w-full" defaultValue={reservationDuration} name="reservationDurationMinutes">
              <option value="60">1 heure</option>
              <option value="90">1 heure 30</option>
              <option value="120">2 heures</option>
              <option value="150">2 heures 30</option>
              <option value="180">3 heures</option>
            </select>
          </label>
          <label className="flex items-center gap-3 rounded-md bg-linen p-3 text-sm font-bold">
            <input className="h-4 w-4 accent-moss" defaultChecked={oneReservationPerService} type="checkbox" />
            Une réservation par table et par service
          </label>
          <label className="flex items-center gap-3 rounded-md bg-linen p-3 text-sm font-bold">
            <input className="h-4 w-4 accent-moss" defaultChecked={minimumAdvanceBooking} type="checkbox" />
            Réservation minimum deux heures avant
          </label>
        </div>
      </div>
    );
  }

  if (page === "Tags") {
    return (
      <div>
        <PanelHeader title="Tags" description="Critères utilisés pour qualifier les tables et les préférences clients." />
        <div className="mt-4 flex flex-wrap gap-2">
          {["Calme", "PMR", "Enfants en bas âge", "Chaise haute", "Vue", "VIP", "Anniversaire", "Romantique"].map((tag) => (
            <span key={tag} className="rounded-full bg-sage px-3 py-1 text-sm font-black text-moss">{tag}</span>
          ))}
        </div>
      </div>
    );
  }

  if (page === "Types de réservation") {
    return (
      <div>
        <PanelHeader title="Types de réservation" description="Catégories de réservation visibles dans le parcours client et côté restaurant." />
        <div className="mt-4 grid gap-2 md:grid-cols-3">
          {["Midi", "Soir", "Groupe", "Anniversaire", "Dîner romantique", "Privatisation"].map((type) => (
            <label key={type} className="flex items-center gap-3 rounded-md bg-linen p-3 text-sm font-bold">
              <input className="h-4 w-4 accent-moss" defaultChecked type="checkbox" />
              {type}
            </label>
          ))}
        </div>
      </div>
    );
  }

  if (page === "Connexions") {
    return (
      <div>
        <PanelHeader title="Connexions" description="Canaux connectés au restaurant pour recevoir et suivre les réservations." />
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <SettingCard label="Site restaurant" value={`${restaurant.slug}.toquetop.com`} />
          <SettingCard label="Notifications email" value="Actives" />
          <SettingCard label="Notifications SMS" value="Configurables" />
          <SettingCard label="Temps réel" value="Actif" />
        </div>
      </div>
    );
  }

  return (
    <div>
      <PanelHeader title="Avancé" description="Paramètres techniques, sécurité et comportement avancé du dashboard." />
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <SettingCard label="Identifiant restaurant" value={restaurant.id} />
        <SettingCard label="Socket room" value={`restaurant:${restaurant.id}`} />
        <SettingCard label="Slug" value={restaurant.slug} />
        <SettingCard label="Mode live" value="Activé" />
      </div>
    </div>
  );
}

type OpeningServiceCount = 1 | 2 | 3;

type SpecialOpeningPeriod = {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  active: boolean;
  serviceCount: OpeningServiceCount;
  openingHours: OpeningHours;
};

function readSpecialOpeningPeriods(settings: Record<string, unknown>, fallbackOpeningHours: OpeningHours): SpecialOpeningPeriod[] {
  const value = settings.specialOpeningPeriods;

  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .filter((period): period is Record<string, unknown> => Boolean(period) && typeof period === "object")
    .map((period, index) => ({
      id: typeof period.id === "string" ? period.id : `period-${index}`,
      name: typeof period.name === "string" && period.name.trim() ? period.name : "Période spéciale",
      startDate: typeof period.startDate === "string" ? period.startDate : today(),
      endDate: typeof period.endDate === "string" ? period.endDate : today(),
      active: period.active !== false,
      serviceCount: period.serviceCount === 1 || period.serviceCount === 2 || period.serviceCount === 3 ? period.serviceCount : 2,
      openingHours: isOpeningHours(period.openingHours) ? period.openingHours : fallbackOpeningHours
    }));
}

function isOpeningHours(value: unknown): value is OpeningHours {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function cloneOpeningHours(openingHours: OpeningHours): OpeningHours {
  return JSON.parse(JSON.stringify(openingHours)) as OpeningHours;
}

function openingHoursForServiceCount(openingHours: OpeningHours, serviceCount: OpeningServiceCount): OpeningHours {
  return Object.fromEntries(
    Object.entries(openingHours).map(([day, hours]) => [
      day,
      {
        ...hours,
        ...(serviceCount < 3 ? { morningOpen: undefined, morningClose: undefined } : {}),
        secondServiceEnabled: serviceCount >= 2,
        ...(serviceCount < 2 ? { secondOpen: undefined, secondClose: undefined } : {}),
        thirdServiceEnabled: false,
        thirdOpen: undefined,
        thirdClose: undefined
      }
    ])
  ) as OpeningHours;
}

function specialOpeningHoursForServiceCount(openingHours: OpeningHours, serviceCount: OpeningServiceCount): OpeningHours {
  return Object.fromEntries(
    Object.entries(openingHours).map(([day, hours]) => [
      day,
      {
        ...hours,
        ...(serviceCount < 3 ? { morningOpen: undefined, morningClose: undefined } : {}),
        ...(serviceCount < 2 ? { secondServiceEnabled: false, secondOpen: undefined, secondClose: undefined } : {}),
        thirdServiceEnabled: false,
        thirdOpen: undefined,
        thirdClose: undefined
      }
    ])
  ) as OpeningHours;
}

function openingServiceCountFromRestaurant(restaurant: Restaurant): OpeningServiceCount {
  const configured = restaurant.settings.openingServiceCount;

  if (configured === 1 || configured === 2 || configured === 3) {
    return configured;
  }

  const dayValues = Object.values(restaurant.openingHours);
  const hasMorning = dayValues.some((hours) => Boolean(hours.morningOpen || hours.morningClose));
  const hasThird = dayValues.some((hours) => Boolean(hours.thirdServiceEnabled || hours.thirdOpen || hours.thirdClose));
  const hasDinner = dayValues.some((hours) => Boolean(hours.secondServiceEnabled || hours.secondOpen || hours.secondClose));

  if (hasMorning || hasThird) {
    return 3;
  }

  return hasDinner ? 2 : 1;
}

function openingDaySummary(hours: OpeningHours[string] | undefined, serviceCount: OpeningServiceCount) {
  if (!hours || hours.closed) {
    return "Fermé";
  }

  const windows = [
    serviceCount === 3 && hours.morningOpen && hours.morningClose ? `Matin ${hours.morningOpen} - ${hours.morningClose}` : null,
    hours.lunchServiceEnabled === false ? null : `Midi ${hours.open} - ${hours.close}`,
    serviceCount >= 2 && hours.secondServiceEnabled !== false ? `Soir ${hours.secondOpen ?? "19:00"} - ${hours.secondClose ?? "22:00"}` : null
  ].filter(Boolean);

  return windows.length > 0 ? windows.join(" · ") : "Fermé";
}

function OpeningHoursPanel({ restaurant }: { restaurant: Restaurant }) {
  const queryClient = useQueryClient();
  const [serviceCount, setServiceCount] = useState<OpeningServiceCount>(() => openingServiceCountFromRestaurant(restaurant));
  const [dayShiftEnabled, setDayShiftEnabled] = useState(Boolean(restaurant.settings.shiftEarlyMorningToPreviousDay));
  const [openingHoursDraft, setOpeningHoursDraft] = useState<OpeningHours>(() => cloneOpeningHours(restaurant.openingHours));
  const [periods, setPeriods] = useState<SpecialOpeningPeriod[]>(() =>
    readSpecialOpeningPeriods(restaurant.settings, cloneOpeningHours(restaurant.openingHours))
  );
  const [periodDraft, setPeriodDraft] = useState<SpecialOpeningPeriod | null>(null);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [expandedDays, setExpandedDays] = useState<Record<string, boolean>>({});
  const openingSnapshot = useMemo(
    () =>
      JSON.stringify({
        openingHours: openingHoursForServiceCount(openingHoursDraft, serviceCount),
        openingServiceCount: serviceCount,
        shiftEarlyMorningToPreviousDay: dayShiftEnabled,
        specialOpeningPeriods: periods.map((period) => ({
          ...period,
          openingHours: specialOpeningHoursForServiceCount(period.openingHours, period.serviceCount)
        }))
      }),
    [dayShiftEnabled, openingHoursDraft, periods, serviceCount]
  );
  const initialOpeningSnapshot = useMemo(
    () =>
      JSON.stringify({
        openingHours: openingHoursForServiceCount(cloneOpeningHours(restaurant.openingHours), openingServiceCountFromRestaurant(restaurant)),
        openingServiceCount: openingServiceCountFromRestaurant(restaurant),
        shiftEarlyMorningToPreviousDay: Boolean(restaurant.settings.shiftEarlyMorningToPreviousDay),
        specialOpeningPeriods: readSpecialOpeningPeriods(restaurant.settings, cloneOpeningHours(restaurant.openingHours)).map((period) => ({
          ...period,
          openingHours: specialOpeningHoursForServiceCount(period.openingHours, period.serviceCount)
        }))
      }),
    [restaurant]
  );
  const [savedOpeningSnapshot, setSavedOpeningSnapshot] = useState(initialOpeningSnapshot);
  const hasUnsavedOpeningChanges = openingSnapshot !== savedOpeningSnapshot;

  const saveOpeningHoursMutation = useMutation({
    mutationFn: () => {
      const nextOpeningHours = openingHoursForServiceCount(openingHoursDraft, serviceCount);
      const nextPeriods = periods.map((period) => ({
        ...period,
        openingHours: specialOpeningHoursForServiceCount(period.openingHours, period.serviceCount)
      }));

      return apiFetch<{ restaurant: Restaurant }>(`/api/restaurants/${restaurant.id}`, {
        method: "PATCH",
        body: JSON.stringify({
          openingHours: nextOpeningHours,
          settings: {
            ...restaurant.settings,
            openingServiceCount: serviceCount,
            shiftEarlyMorningToPreviousDay: dayShiftEnabled,
            specialOpeningPeriods: nextPeriods
          }
        })
      });
    },
    onSuccess: () => {
      setSaveMessage("Modification effectuée");
      setSavedOpeningSnapshot(openingSnapshot);
      void queryClient.invalidateQueries({ queryKey: ["current-restaurants"] });
      window.setTimeout(() => setSaveMessage(null), 2500);
    },
    onError: (error) => {
      setSaveMessage(error instanceof Error ? error.message : "Impossible d’enregistrer les horaires.");
    }
  });

  useEffect(() => {
    setSavedOpeningSnapshot(initialOpeningSnapshot);
  }, [initialOpeningSnapshot]);

  useEffect(() => {
    if (!hasUnsavedOpeningChanges) {
      return;
    }

    function handleBeforeUnload(event: BeforeUnloadEvent) {
      event.preventDefault();
      event.returnValue = "";
    }

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [hasUnsavedOpeningChanges]);

  function updateOpeningHour(day: string, updates: Partial<OpeningHours[string]>) {
    setOpeningHoursDraft((current) => ({
      ...current,
      [day]: {
        ...(current[day] ?? { open: "12:00", close: "14:00" }),
        ...updates
      }
    }));
  }

  function updatePeriodDraft(updates: Partial<SpecialOpeningPeriod>) {
    setPeriodDraft((current) => current ? { ...current, ...updates } : current);
  }

  function updatePeriodDay(day: string, updates: Partial<OpeningHours[string]>) {
    setPeriodDraft((current) => {
      if (!current) {
        return current;
      }

      return {
        ...current,
        openingHours: {
          ...current.openingHours,
          [day]: {
            ...(current.openingHours[day] ?? { open: "12:00", close: "14:00" }),
            ...updates
          }
        }
      };
    });
  }

  function createPeriod() {
    setPeriodDraft({
      id: `period-${Date.now()}`,
      name: "",
      startDate: today(),
      endDate: today(),
      active: true,
      serviceCount,
      openingHours: cloneOpeningHours(openingHoursDraft)
    });
  }

  function savePeriod() {
    if (!periodDraft) {
      return;
    }

    const nextPeriod = {
      ...periodDraft,
      name: periodDraft.name.trim() || "Période spéciale"
    };

    setPeriods((current) => {
      const exists = current.some((period) => period.id === nextPeriod.id);

      return exists
        ? current.map((period) => period.id === nextPeriod.id ? nextPeriod : period)
        : [...current, nextPeriod];
    });
    setPeriodDraft(null);
  }

  function editPeriod(period: SpecialOpeningPeriod) {
    setPeriodDraft({
      ...period,
      openingHours: cloneOpeningHours(period.openingHours)
    });
  }

  function removePeriod(periodId: string) {
    setPeriods((current) => current.filter((period) => period.id !== periodId));
    setPeriodDraft((current) => current?.id === periodId ? null : current);
  }

  function togglePeriod(periodId: string) {
    setPeriods((current) =>
      current.map((period) => period.id === periodId ? { ...period, active: !period.active } : period)
    );
  }

  function discardOpeningChanges() {
    const nextServiceCount = openingServiceCountFromRestaurant(restaurant);
    setServiceCount(nextServiceCount);
    setDayShiftEnabled(Boolean(restaurant.settings.shiftEarlyMorningToPreviousDay));
    setOpeningHoursDraft(cloneOpeningHours(restaurant.openingHours));
    setPeriods(readSpecialOpeningPeriods(restaurant.settings, cloneOpeningHours(restaurant.openingHours)));
    setPeriodDraft(null);
    setSavedOpeningSnapshot(initialOpeningSnapshot);
    setSaveMessage("Modifications ignorées");
    window.setTimeout(() => setSaveMessage(null), 2500);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <PanelHeader title="Heures d’ouverture" description="Configurez les services, les jours ouverts et les horaires utilisés par le moteur de réservation." />
        <div className="flex flex-wrap items-center justify-end gap-2">
          {saveMessage ? <p className="text-sm font-black text-moss">{saveMessage}</p> : null}
          <button
            className="primary-button"
            disabled={saveOpeningHoursMutation.isPending}
            type="button"
            onClick={() => saveOpeningHoursMutation.mutate()}
          >
            {saveOpeningHoursMutation.isPending ? "Enregistrement..." : "Enregistrer"}
          </button>
        </div>
      </div>

      {hasUnsavedOpeningChanges ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-amber-200 bg-amber-50 p-3 text-sm font-bold text-amber-950">
          <p>Des modifications ne sont pas enregistrées. Voulez-vous les enregistrer ?</p>
          <div className="flex flex-wrap gap-2">
            <button className="secondary-button h-9 px-3 text-xs" type="button" onClick={discardOpeningChanges}>Ignorer</button>
            <button
              className="primary-button h-9 px-3 text-xs"
              disabled={saveOpeningHoursMutation.isPending}
              type="button"
              onClick={() => saveOpeningHoursMutation.mutate()}
            >
              Enregistrer
            </button>
          </div>
        </div>
      ) : null}

      <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-xs font-semibold leading-5 text-amber-950">
        <p className="font-black uppercase tracking-[0.12em] text-amber-700">Important</p>
        <p className="mt-1">
          L’heure de fermeture correspond à l’heure à laquelle la dernière réservation doit se terminer, et non à l’heure de dernière arrivée.
          Par exemple, si la fermeture est définie à 22 h et qu’une réservation dure 2 heures, la dernière arrivée possible sera à 20h.
        </p>
      </div>

      <div className="grid max-w-4xl gap-3 lg:grid-cols-[minmax(0,1fr)_210px]">
        <div className="rounded-md border border-ink/10 bg-linen p-3">
          <p className="text-xs font-black uppercase tracking-[0.14em] text-ink/45">Services proposés</p>
          <div className="mt-2 grid gap-2 sm:grid-cols-3">
            {[
              { value: 1 as const, label: "1 service", detail: "Midi" },
              { value: 2 as const, label: "2 services", detail: "Midi / soir" },
              { value: 3 as const, label: "3 services", detail: "Matin / midi / soir" }
            ].map((option) => (
              <button
                key={option.value}
                className={clsx(
                  "rounded-md border p-2 text-left text-xs font-black transition",
                  serviceCount === option.value ? "border-moss bg-moss text-white" : "border-ink/10 bg-white hover:bg-sage/60"
                )}
                type="button"
                onClick={() => setServiceCount(option.value)}
              >
                {option.label}
                <span className={clsx("mt-1 block text-xs font-semibold", serviceCount === option.value ? "text-white/75" : "text-ink/50")}>
                  {option.detail}
                </span>
              </button>
            ))}
          </div>
        </div>

        <label className="relative flex min-h-full items-center justify-center gap-3 rounded-md border border-ink/10 bg-linen p-3 text-center text-sm font-bold">
          <input
            checked={dayShiftEnabled}
            className="h-4 w-4 accent-moss"
            type="checkbox"
            onChange={(event) => setDayShiftEnabled(event.target.checked)}
          />
          <span>
            Jour décalé
            <span className="group relative ml-2 inline-flex align-middle">
              <Info className="h-4 w-4 text-moss" />
              <span className="pointer-events-none absolute right-0 top-6 z-10 hidden w-72 rounded-md border border-ink/10 bg-white p-3 text-xs font-semibold leading-5 text-ink/70 shadow-soft group-hover:block">
                Lorsque l’option est activée, les réservations dont l’heure de début se situe entre minuit et 5h du matin peuvent être rattachées à la journée précédente, à condition que les horaires d’ouverture le permettent. Cette option est particulièrement utile pour les établissements ouverts après minuit, comme les bars, clubs ou restaurants de nuit.
              </span>
            </span>
          </span>
        </label>
      </div>

      <div className="grid gap-3">
        {dayKeys.map((day) => {
          const hours = openingHoursDraft[day] ?? { open: "12:00", close: "14:00" };

          return (
            <div key={day} className="rounded-md border border-ink/10 bg-linen">
              <button
                className="flex w-full items-center justify-between gap-3 p-3 text-left"
                type="button"
                onClick={() => setExpandedDays((current) => ({ ...current, [day]: !current[day] }))}
              >
                <span className="flex min-w-0 flex-1 flex-wrap items-center gap-3">
                  <span className="text-sm font-black">{dayLabels[day]}</span>
                  <span className="min-w-0 text-sm font-semibold text-ink/60">{openingDaySummary(hours, serviceCount)}</span>
                </span>
                {expandedDays[day] ? <ChevronUp className="h-4 w-4 shrink-0 text-ink/50" /> : <ChevronDown className="h-4 w-4 shrink-0 text-ink/50" />}
              </button>
              {expandedDays[day] ? (
                <div className="border-t border-ink/10 p-3">
                  <label className="flex items-center gap-3 text-sm font-black">
                    <input
                      checked={!hours.closed}
                      className="h-4 w-4 accent-moss"
                      type="checkbox"
                      onChange={(event) => updateOpeningHour(day, { closed: !event.target.checked })}
                    />
                    Jour ouvert
                  </label>
                  {hours.closed ? (
                    <p className="mt-3 rounded-md bg-white px-3 py-2 text-sm font-black text-ink/55">Fermé</p>
                  ) : (
                    <div className="mt-3 grid gap-3">
                  {serviceCount === 3 ? (
                    <ServiceTimeRow
                      close={hours.morningClose ?? "11:00"}
                      disabled={false}
                      label="Matin"
                      open={hours.morningOpen ?? "08:00"}
                      onChange={(updates) => updateOpeningHour(day, updates)}
                      openKey="morningOpen"
                      closeKey="morningClose"
                    />
                  ) : null}
                  <ServiceTimeRow
                    close={hours.close}
                    disabled={false}
                    label="Midi"
                    open={hours.open}
                    onChange={(updates) => updateOpeningHour(day, updates)}
                    openKey="open"
                    closeKey="close"
                  />
                  {serviceCount >= 2 ? (
                    <ServiceTimeRow
                      close={hours.secondClose ?? "22:00"}
                      disabled={false}
                      label="Soir"
                      open={hours.secondOpen ?? "19:00"}
                      onChange={(updates) =>
                        updateOpeningHour(day, {
                          secondServiceEnabled: true,
                          ...updates
                        })
                      }
                      openKey="secondOpen"
                      closeKey="secondClose"
                    />
                  ) : null}
                </div>
              )}
                </div>
              ) : null}
            </div>
          );
        })}
      </div>

      <div className="rounded-md border border-ink/10 bg-linen p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-black">Périodes spéciales</h3>
            <p className="mt-1 text-sm font-semibold text-ink/55">
              Créez une période avec des horaires différents. Elle remplacera les horaires de base sur les dates indiquées.
            </p>
          </div>
          <button className="primary-button" type="button" onClick={createPeriod}>
            <Plus className="h-4 w-4" />
            Créer une période
          </button>
        </div>

        {periodDraft ? (
          <div className="mt-4 rounded-md border border-moss/20 bg-white p-4">
            <div className="grid gap-3 md:grid-cols-3">
              <InputField defaultValue={periodDraft.name} label="Nom" name="periodName" onChange={(value) => updatePeriodDraft({ name: value })} />
              <InputField defaultValue={periodDraft.startDate} label="Date de début" name="periodStartDate" type="date" onChange={(value) => updatePeriodDraft({ startDate: value })} />
              <InputField defaultValue={periodDraft.endDate} label="Date de fin" name="periodEndDate" type="date" onChange={(value) => updatePeriodDraft({ endDate: value })} />
            </div>
            <div className="mt-4 rounded-md bg-linen p-3">
              <p className="text-xs font-black uppercase tracking-[0.14em] text-ink/45">Services de la période</p>
              <div className="mt-2 grid gap-2 sm:grid-cols-3">
                {[
                  { value: 1 as const, label: "1 service" },
                  { value: 2 as const, label: "2 services" },
                  { value: 3 as const, label: "3 services" }
                ].map((option) => (
                  <button
                    key={option.value}
                    className={clsx(
                      "rounded-md border p-2 text-left text-xs font-black transition",
                      periodDraft.serviceCount === option.value ? "border-moss bg-moss text-white" : "border-ink/10 bg-white hover:bg-sage/60"
                    )}
                    type="button"
                    onClick={() => updatePeriodDraft({ serviceCount: option.value })}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-4 grid gap-3">
              {dayKeys.map((day) => {
                const hours = periodDraft.openingHours[day] ?? { open: "12:00", close: "14:00" };

                return (
                  <div key={day} className="rounded-md bg-linen p-3">
                    <label className="flex items-center gap-3 text-sm font-black">
                      <input
                        checked={!hours.closed}
                        className="h-4 w-4 accent-moss"
                        type="checkbox"
                        onChange={(event) => updatePeriodDay(day, { closed: !event.target.checked })}
                      />
                      {dayLabels[day]}
                    </label>
                    {hours.closed ? (
                      <p className="mt-3 rounded-md bg-white px-3 py-2 text-sm font-black text-ink/55">Fermé</p>
                    ) : (
                      <div className="mt-3 grid gap-3">
                        {periodDraft.serviceCount === 3 ? (
                          <ServiceTimeRow
                            close={hours.morningClose ?? "11:00"}
                            closeKey="morningClose"
                            disabled={false}
                            enabled={Boolean(hours.morningOpen && hours.morningClose)}
                            label="Matin"
                            open={hours.morningOpen ?? "08:00"}
                            openKey="morningOpen"
                            onChange={(updates) => updatePeriodDay(day, updates)}
                            onEnabledChange={(enabled) =>
                              updatePeriodDay(day, {
                                morningOpen: enabled ? hours.morningOpen ?? "08:00" : undefined,
                                morningClose: enabled ? hours.morningClose ?? "11:00" : undefined
                              })
                            }
                          />
                        ) : null}
                        <ServiceTimeRow
                          close={hours.close}
                          closeKey="close"
                          disabled={false}
                          enabled={hours.lunchServiceEnabled !== false}
                          label="Midi"
                          open={hours.open}
                          openKey="open"
                          onChange={(updates) => updatePeriodDay(day, updates)}
                          onEnabledChange={(enabled) => updatePeriodDay(day, { lunchServiceEnabled: enabled })}
                        />
                        {periodDraft.serviceCount >= 2 ? (
                          <ServiceTimeRow
                            close={hours.secondClose ?? "22:00"}
                            closeKey="secondClose"
                            disabled={false}
                            enabled={Boolean(hours.secondServiceEnabled)}
                            label="Soir"
                            open={hours.secondOpen ?? "19:00"}
                            openKey="secondOpen"
                            onChange={(updates) =>
                              updatePeriodDay(day, {
                                secondServiceEnabled: true,
                                ...updates
                              })
                            }
                            onEnabledChange={(enabled) =>
                              updatePeriodDay(day, {
                                secondServiceEnabled: enabled,
                                secondOpen: enabled ? hours.secondOpen ?? "19:00" : hours.secondOpen,
                                secondClose: enabled ? hours.secondClose ?? "22:00" : hours.secondClose
                              })
                            }
                          />
                        ) : null}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <button className="secondary-button" type="button" onClick={() => setPeriodDraft(null)}>Annuler</button>
              <button className="primary-button" type="button" onClick={savePeriod}>Enregistrer la période</button>
            </div>
          </div>
        ) : null}

        <div className="mt-4 grid gap-2">
          {periods.length === 0 ? (
            <p className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-ink/60">Aucune période spécifique configurée.</p>
          ) : null}
          {periods.map((period) => (
            <div key={period.id} className="grid gap-3 rounded-md border border-ink/10 bg-white p-3 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
              <div>
                <p className="font-black">{period.name}</p>
                <p className="text-sm font-semibold text-ink/55">{formatPeriodDate(period.startDate)} au {formatPeriodDate(period.endDate)}</p>
                <span className={clsx("mt-2 inline-flex rounded-full px-2 py-1 text-xs font-black", period.active ? "bg-moss/10 text-moss" : "bg-ink/10 text-ink/50")}>
                  {period.active ? "Active" : "Désactivée"}
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                <button className="secondary-button h-9 px-3 text-xs" type="button" onClick={() => editPeriod(period)}>Modifier</button>
                <button className="secondary-button h-9 px-3 text-xs" type="button" onClick={() => togglePeriod(period.id)}>
                  {period.active ? "Désactiver" : "Activer"}
                </button>
                <button className="danger-button h-9 px-3 text-xs" type="button" onClick={() => removePeriod(period.id)}>Supprimer</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function readVacationClosures(settings: Record<string, unknown>): VacationClosure[] {
  const value = settings.vacationClosures;

  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .filter((closure): closure is Record<string, unknown> => Boolean(closure) && typeof closure === "object")
    .map((closure, index) => ({
      id: typeof closure.id === "string" ? closure.id : `closure-${index}`,
      startDate: typeof closure.startDate === "string" ? closure.startDate : today(),
      endDate: typeof closure.endDate === "string" ? closure.endDate : today(),
      label: typeof closure.label === "string" ? closure.label : "Fermeture",
      active: closure.active !== false
    }));
}

function ClosuresPanel({ restaurant }: { restaurant: Restaurant }) {
  const queryClient = useQueryClient();
  const [closures, setClosures] = useState<VacationClosure[]>(() => readVacationClosures(restaurant.settings));
  const [closureDraft, setClosureDraft] = useState<VacationClosure | null>(null);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const saveClosuresMutation = useMutation({
    mutationFn: () =>
      apiFetch<{ restaurant: Restaurant }>(`/api/restaurants/${restaurant.id}`, {
        method: "PATCH",
        body: JSON.stringify({
          settings: {
            ...restaurant.settings,
            vacationClosures: closures
          }
        })
      }),
    onSuccess: () => {
      setSaveMessage("Modification effectuée");
      void queryClient.invalidateQueries({ queryKey: ["current-restaurants"] });
      window.setTimeout(() => setSaveMessage(null), 2500);
    },
    onError: (error) => {
      setSaveMessage(error instanceof Error ? error.message : "Impossible d’enregistrer les congés.");
    }
  });

  function createClosure() {
    setClosureDraft({
      id: `closure-${Date.now()}`,
      startDate: today(),
      endDate: today(),
      label: "",
      active: true
    });
  }

  function updateClosureDraft(updates: Partial<VacationClosure>) {
    setClosureDraft((current) => current ? { ...current, ...updates } : current);
  }

  function saveClosureDraft() {
    if (!closureDraft) {
      return;
    }

    const nextClosure = {
      ...closureDraft,
      label: closureDraft.label?.trim() || "Fermeture"
    };

    setClosures((current) => {
      const exists = current.some((closure) => closure.id === nextClosure.id);

      return exists
        ? current.map((closure) => closure.id === nextClosure.id ? nextClosure : closure)
        : [...current, nextClosure];
    });
    setClosureDraft(null);
  }

  function editClosure(closure: VacationClosure) {
    setClosureDraft({ ...closure });
  }

  function toggleClosure(closureId: string) {
    setClosures((current) =>
      current.map((closure) => closure.id === closureId ? { ...closure, active: closure.active === false } : closure)
    );
  }

  function removeClosure(closureId: string) {
    setClosures((current) => current.filter((closure) => closure.id !== closureId));
    setClosureDraft((current) => current?.id === closureId ? null : current);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <PanelHeader title="Congés" description="Ajoutez les périodes de fermeture de l’établissement. Les réservations seront bloquées sur les périodes actives." />
        <div className="flex flex-wrap items-center justify-end gap-2">
          {saveMessage ? <p className="text-sm font-black text-moss">{saveMessage}</p> : null}
          <button
            className="primary-button"
            disabled={saveClosuresMutation.isPending}
            type="button"
            onClick={() => saveClosuresMutation.mutate()}
          >
            {saveClosuresMutation.isPending ? "Enregistrement..." : "Enregistrer"}
          </button>
        </div>
      </div>

      <div className="rounded-md border border-ink/10 bg-linen p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-black">Périodes de fermeture</h3>
            <p className="mt-1 text-sm font-semibold text-ink/55">Créez plusieurs périodes, puis activez ou désactivez-les selon vos besoins.</p>
          </div>
          <button className="primary-button" type="button" onClick={createClosure}>
            <Plus className="h-4 w-4" />
            Ajouter un congé
          </button>
        </div>

        {closureDraft ? (
          <div className="mt-4 rounded-md border border-moss/20 bg-white p-4">
            <div className="grid gap-3 md:grid-cols-3">
              <InputField defaultValue={closureDraft.label ?? ""} label="Nom" name="closureName" onChange={(value) => updateClosureDraft({ label: value })} />
              <InputField defaultValue={closureDraft.startDate} label="Date de début" name="closureStartDate" type="date" onChange={(value) => updateClosureDraft({ startDate: value })} />
              <InputField defaultValue={closureDraft.endDate} label="Date de fin" name="closureEndDate" type="date" onChange={(value) => updateClosureDraft({ endDate: value })} />
            </div>
            <label className="mt-4 flex items-center gap-3 rounded-md bg-linen p-3 text-sm font-bold">
              <input
                checked={closureDraft.active !== false}
                className="h-4 w-4 accent-moss"
                type="checkbox"
                onChange={(event) => updateClosureDraft({ active: event.target.checked })}
              />
              Congé actif
            </label>
            <div className="mt-4 flex justify-end gap-2">
              <button className="secondary-button" type="button" onClick={() => setClosureDraft(null)}>Annuler</button>
              <button className="primary-button" type="button" onClick={saveClosureDraft}>Enregistrer le congé</button>
            </div>
          </div>
        ) : null}

        <div className="mt-4 grid gap-2">
          {closures.length === 0 ? (
            <p className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-ink/60">Aucun congé configuré.</p>
          ) : null}
          {closures.map((closure) => (
            <div key={closure.id} className="grid gap-3 rounded-md border border-ink/10 bg-white p-3 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
              <div>
                <p className="font-black">{closure.label || "Fermeture"}</p>
                <p className="text-sm font-semibold text-ink/55">{formatPeriodDate(closure.startDate)} au {formatPeriodDate(closure.endDate)}</p>
                <span className={clsx("mt-2 inline-flex rounded-full px-2 py-1 text-xs font-black", closure.active === false ? "bg-ink/10 text-ink/50" : "bg-red-50 text-red-700")}>
                  {closure.active === false ? "Désactivé" : "Fermeture active"}
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                <button className="secondary-button h-9 px-3 text-xs" type="button" onClick={() => editClosure(closure)}>Modifier</button>
                <button className="secondary-button h-9 px-3 text-xs" type="button" onClick={() => toggleClosure(closure.id)}>
                  {closure.active === false ? "Activer" : "Désactiver"}
                </button>
                <button className="danger-button h-9 px-3 text-xs" type="button" onClick={() => removeClosure(closure.id)}>Supprimer</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

type OpeningHourFieldKey = "morningOpen" | "morningClose" | "open" | "close" | "secondOpen" | "secondClose";

function ServiceTimeRow({
  close,
  closeKey,
  disabled,
  enabled = true,
  label,
  onChange,
  onEnabledChange,
  open,
  openKey
}: {
  close: string;
  closeKey: OpeningHourFieldKey;
  disabled: boolean;
  enabled?: boolean;
  label: string;
  onChange: (updates: Partial<OpeningHours[string]>) => void;
  onEnabledChange?: (enabled: boolean) => void;
  open: string;
  openKey: OpeningHourFieldKey;
}) {
  return (
    <div className="grid gap-2 md:grid-cols-[120px_minmax(0,1fr)_minmax(0,1fr)] md:items-end">
      <div>
        {onEnabledChange ? (
          <label className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.12em] text-ink/45">
            <input
              checked={enabled}
              className="h-4 w-4 accent-moss"
              disabled={disabled}
              type="checkbox"
              onChange={(event) => onEnabledChange(event.target.checked)}
            />
            {label}
          </label>
        ) : (
          <p className="text-xs font-black uppercase tracking-[0.12em] text-ink/45">{label}</p>
        )}
      </div>
      {!enabled ? (
        <p className="rounded-md bg-white px-3 py-2 text-sm font-black text-ink/45 md:col-span-2">Service désactivé</p>
      ) : (
        <>
      <label className="text-xs font-bold text-ink/60">
        Ouverture
        <select
          className="control mt-1 h-10 w-full"
          disabled={disabled || !enabled}
          value={open}
          onChange={(event) => onChange({ [openKey]: event.target.value } as Partial<OpeningHours[string]>)}
        >
          {timeOptions.map((time) => (
            <option key={`${label}-${openKey}-${time}`} value={time}>{time}</option>
          ))}
        </select>
      </label>
      <label className="text-xs font-bold text-ink/60">
        Fermeture
        <select
          className="control mt-1 h-10 w-full"
          disabled={disabled || !enabled}
          value={close}
          onChange={(event) => onChange({ [closeKey]: event.target.value } as Partial<OpeningHours[string]>)}
        >
          {timeOptions.map((time) => (
            <option key={`${label}-${closeKey}-${time}`} value={time}>{time}</option>
          ))}
        </select>
      </label>
        </>
      )}
    </div>
  );
}

function PanelHeader({ description, title }: { description: string; title: string }) {
  return (
    <div>
      <h2 className="text-xl font-black">{title}</h2>
      <p className="mt-1 text-sm font-semibold leading-6 text-ink/55">{description}</p>
    </div>
  );
}

function SettingCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-ink/10 bg-linen p-3">
      <p className="text-xs font-black uppercase tracking-[0.12em] text-ink/45">{label}</p>
      <p className="mt-1 break-words text-sm font-black text-ink">{value}</p>
    </div>
  );
}

function CrmPanel({
  clients,
  clientSearch,
  setClientSearch,
  onCreate
}: {
  clients: Client[];
  clientSearch: string;
  setClientSearch: (value: string) => void;
  onCreate: () => void;
}) {
  return (
    <section className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-black">CRM clients</h2>
          <p className="text-sm font-semibold text-ink/55">Fiches clients, allergies, préférences, no-shows et statut VIP.</p>
        </div>
        <button className="primary-button" type="button" onClick={onCreate}>
          <Plus className="h-4 w-4" />
          Client
        </button>
      </div>
      <input
        className="control mt-3 w-full"
        placeholder="Rechercher par nom, email ou téléphone"
        value={clientSearch}
        onChange={(event) => setClientSearch(event.target.value)}
      />
      <div className="mt-3 grid gap-2 lg:grid-cols-2">
        {clients.map((client) => (
          <article key={client.id} className="rounded-md border border-ink/10 bg-linen p-3">
            <div className="flex items-center justify-between gap-3">
              <h3 className="font-black">{client.firstName} {client.lastName}</h3>
              {client.vip ? <span className="rounded-full bg-moss/10 px-2 py-1 text-xs font-black text-moss">VIP</span> : null}
            </div>
            <p className="mt-1 text-xs font-semibold text-ink/60">{client.email ?? "Sans email"} · {client.phone ?? "Sans téléphone"}</p>
            <p className="mt-2 text-xs font-semibold text-ink/70">Allergies : {client.allergies || "Aucune"}</p>
            <p className="text-xs font-semibold text-ink/70">Risque no-show : {client.noShowRisk}/100</p>
            <p className="mt-2 text-xs font-semibold text-ink/50">{client.reservations.length} réservation(s) récentes</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function TemplatesPanel({ restaurantId }: { restaurantId: string }) {
  const templatesQuery = useQuery({
    queryKey: ["templates", restaurantId],
    queryFn: () => apiFetch<{ templates: Array<{ id: string; key: string; channel: string; enabled: boolean; subject: string | null }> }>(`/api/restaurants/${restaurantId}/templates`)
  });
  const templates = templatesQuery.data?.templates ?? [];

  return (
    <section className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
      <h2 className="text-lg font-black">Notifications</h2>
      <p className="text-sm font-semibold text-ink/55">Templates email/SMS éditables avec variables.</p>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {templates.map((template) => (
          <div key={template.id} className="rounded-md border border-ink/10 bg-linen p-3">
            <p className="font-black">{template.key}</p>
            <p className="text-xs font-semibold text-ink/60">{template.channel} · {template.enabled ? "Actif" : "Inactif"}</p>
          </div>
        ))}
        {templates.length === 0 ? <p className="text-sm font-semibold text-ink/55">Aucun template restaurant personnalisé.</p> : null}
      </div>
    </section>
  );
}

function PlaceholderPanel({ section }: { section: string }) {
  return (
    <section className="rounded-lg border border-ink/10 bg-white p-4 shadow-soft">
      <h2 className="text-lg font-black">{section}</h2>
      <p className="mt-1 text-sm font-semibold text-ink/55">Section prête pour les réglages V1. Les actions critiques restent dans le Dashboard Live.</p>
    </section>
  );
}

function InputField({
  defaultValue,
  label,
  name,
  onChange,
  type = "text"
}: {
  defaultValue?: string;
  label: string;
  name: string;
  onChange?: (value: string) => void;
  type?: string;
}) {
  return (
    <label className="text-sm font-bold">
      {label}
      <input
        className="control mt-1 w-full"
        defaultValue={defaultValue}
        name={name}
        required={["firstName", "lastName", "email"].includes(name)}
        type={type}
        onChange={(event) => onChange?.(event.target.value)}
      />
    </label>
  );
}

function SelectField({
  defaultValue,
  label,
  name,
  options,
  render
}: {
  defaultValue?: string;
  label: string;
  name: string;
  options: string[];
  render?: (value: string) => string;
}) {
  return (
    <label className="text-sm font-bold">
      {label}
      <select className="control mt-1 w-full" defaultValue={defaultValue} name={name}>
        {options.map((option) => (
          <option key={option || "none"} value={option}>
            {render ? render(option) : option}
          </option>
        ))}
      </select>
    </label>
  );
}

function ReservationForm({
  defaultDate,
  defaultTableId,
  tables,
  onSubmit
}: {
  defaultDate: string;
  defaultTableId?: string;
  tables: FloorTable[];
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
}) {
  return (
    <form className="grid gap-3" onSubmit={onSubmit}>
      <div className="grid gap-3 sm:grid-cols-2">
        <InputField label="Prénom" name="firstName" />
        <InputField label="Nom" name="lastName" />
      </div>
      <InputField label="Email" name="email" type="email" />
      <InputField label="Téléphone" name="phone" />
      <div className="grid gap-3 sm:grid-cols-3">
        <InputField defaultValue={defaultDate} label="Date" name="date" type="date" />
        <SelectField defaultValue="20:00" label="Horaire" name="startTime" options={timeOptions} />
        <InputField defaultValue="2" label="Couverts" name="numberOfGuests" type="number" />
      </div>
      <SelectField
        defaultValue={defaultTableId ?? ""}
        label="Table"
        name="tableId"
        options={["", ...tables.map((table) => table.id)]}
        render={(value) => tables.find((table) => table.id === value)?.label ?? "Laisser choisir"}
      />
      <PreferenceCheckboxes />
      <label className="text-sm font-bold">
        Note
        <textarea className="control mt-1 min-h-20 w-full" name="notes" />
      </label>
      <button className="primary-button w-full" type="submit">Créer la réservation</button>
    </form>
  );
}

function WaitlistForm({ defaultDate, onSubmit }: { defaultDate: string; onSubmit: (event: FormEvent<HTMLFormElement>) => void }) {
  return (
    <form className="grid gap-3" onSubmit={onSubmit}>
      <div className="grid gap-3 sm:grid-cols-2">
        <InputField label="Prénom" name="firstName" />
        <InputField label="Nom" name="lastName" />
      </div>
      <InputField label="Email" name="email" type="email" />
      <InputField label="Téléphone" name="phone" />
      <div className="grid gap-3 sm:grid-cols-3">
        <InputField defaultValue={defaultDate} label="Date" name="date" type="date" />
        <SelectField defaultValue="" label="Heure souhaitée" name="requestedTime" options={["", ...timeOptions]} render={(value) => value || "Flexible"} />
        <InputField defaultValue="2" label="Couverts" name="numberOfGuests" type="number" />
      </div>
      <PreferenceCheckboxes />
      <label className="text-sm font-bold">
        Note
        <textarea className="control mt-1 min-h-20 w-full" name="notes" />
      </label>
      <button className="primary-button w-full" type="submit">Ajouter à la liste</button>
    </form>
  );
}

function ClientForm({ onSubmit }: { onSubmit: (event: FormEvent<HTMLFormElement>) => void }) {
  return (
    <form className="grid gap-3" onSubmit={onSubmit}>
      <div className="grid gap-3 sm:grid-cols-2">
        <InputField label="Prénom" name="firstName" />
        <InputField label="Nom" name="lastName" />
      </div>
      <InputField label="Email" name="email" type="email" />
      <InputField label="Téléphone" name="phone" />
      <InputField label="Anniversaire" name="birthday" type="date" />
      <InputField label="Allergies" name="allergies" />
      <InputField label="Préférences (séparées par virgule)" name="preferences" />
      <label className="text-sm font-bold">
        Notes internes
        <textarea className="control mt-1 min-h-20 w-full" name="internalNotes" />
      </label>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="flex items-center gap-2 text-sm font-bold">
          <input className="h-4 w-4 accent-moss" name="vip" type="checkbox" />
          Statut VIP
        </label>
        <InputField defaultValue="0" label="Risque no-show" name="noShowRisk" type="number" />
      </div>
      <button className="primary-button w-full" type="submit">Créer la fiche client</button>
    </form>
  );
}

function PreferenceCheckboxes() {
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {[
        ["QUIET", "Table au calme"],
        ["ACCESSIBLE", "PMR"],
        ["KIDS", "Enfants en bas âge"],
        ["WINDOW", "Près d’une fenêtre"]
      ].map(([value, label]) => (
        <label key={value} className="flex items-center gap-2 rounded-md bg-linen p-2 text-sm font-bold">
          <input className="h-4 w-4 accent-moss" name={value} type="checkbox" />
          {label}
        </label>
      ))}
      <label className="flex items-center gap-2 rounded-md bg-linen p-2 text-sm font-bold">
        <input className="h-4 w-4 accent-moss" name="highChair" type="checkbox" />
        Chaise haute
      </label>
      <label className="flex items-center gap-2 rounded-md bg-linen p-2 text-sm font-bold">
        <input className="h-4 w-4 accent-moss" name="birthday" type="checkbox" />
        Anniversaire
      </label>
      <label className="flex items-center gap-2 rounded-md bg-linen p-2 text-sm font-bold">
        <input className="h-4 w-4 accent-moss" name="romanticDinner" type="checkbox" />
        Dîner romantique
      </label>
    </div>
  );
}
